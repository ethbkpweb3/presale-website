import {aH as M, aI as rr} from "./index-CNt1EzpG.js";
import {j as nr, s as sr, r as _t, a as Et, b as ir, c as ar} from "./hooks.module-DlYNTax8.js";
function or(r, e) {
    for (var t = 0; t < e.length; t++) {
        const n = e[t];
        if (typeof n != "string" && !Array.isArray(n)) {
            for (const s in n)
                if (s !== "default" && !(s in r)) {
                    const i = Object.getOwnPropertyDescriptor(n, s);
                    i && Object.defineProperty(r, s, i.get ? i : {
                        enumerable: !0,
                        get: () => n[s]
                    })
                }
        }
    }
    return Object.freeze(Object.defineProperty(r, Symbol.toStringTag, {
        value: "Module"
    }))
}
var $e = {}
  , ee = {}
  , fe = {};
Object.defineProperty(fe, "__esModule", {
    value: !0
});
fe.walletLogo = void 0;
const cr = (r, e) => {
    let t;
    switch (r) {
    case "standard":
        return t = e,
        `data:image/svg+xml,%3Csvg width='${e}' height='${t}' viewBox='0 0 1024 1024' fill='none' xmlns='http://www.w3.org/2000/svg'%3E %3Crect width='1024' height='1024' fill='%230052FF'/%3E %3Cpath fill-rule='evenodd' clip-rule='evenodd' d='M152 512C152 710.823 313.177 872 512 872C710.823 872 872 710.823 872 512C872 313.177 710.823 152 512 152C313.177 152 152 313.177 152 512ZM420 396C406.745 396 396 406.745 396 420V604C396 617.255 406.745 628 420 628H604C617.255 628 628 617.255 628 604V420C628 406.745 617.255 396 604 396H420Z' fill='white'/%3E %3C/svg%3E `;
    case "circle":
        return t = e,
        `data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='${e}' height='${t}' viewBox='0 0 999.81 999.81'%3E%3Cdefs%3E%3Cstyle%3E.cls-1%7Bfill:%230052fe;%7D.cls-2%7Bfill:%23fefefe;%7D.cls-3%7Bfill:%230152fe;%7D%3C/style%3E%3C/defs%3E%3Cpath class='cls-1' d='M655-115.9h56c.83,1.59,2.36.88,3.56,1a478,478,0,0,1,75.06,10.42C891.4-81.76,978.33-32.58,1049.19,44q116.7,126,131.94,297.61c.38,4.14-.34,8.53,1.78,12.45v59c-1.58.84-.91,2.35-1,3.56a482.05,482.05,0,0,1-10.38,74.05c-24,106.72-76.64,196.76-158.83,268.93s-178.18,112.82-287.2,122.6c-4.83.43-9.86-.25-14.51,1.77H654c-1-1.68-2.69-.91-4.06-1a496.89,496.89,0,0,1-105.9-18.59c-93.54-27.42-172.78-77.59-236.91-150.94Q199.34,590.1,184.87,426.58c-.47-5.19.25-10.56-1.77-15.59V355c1.68-1,.91-2.7,1-4.06a498.12,498.12,0,0,1,18.58-105.9c26-88.75,72.64-164.9,140.6-227.57q126-116.27,297.21-131.61C645.32-114.57,650.35-113.88,655-115.9Zm377.92,500c0-192.44-156.31-349.49-347.56-350.15-194.13-.68-350.94,155.13-352.29,347.42-1.37,194.55,155.51,352.1,348.56,352.47C876.15,734.23,1032.93,577.84,1032.93,384.11Z' transform='translate(-183.1 115.9)'/%3E%3Cpath class='cls-2' d='M1032.93,384.11c0,193.73-156.78,350.12-351.29,349.74-193-.37-349.93-157.92-348.56-352.47C334.43,189.09,491.24,33.28,685.37,34,876.62,34.62,1032.94,191.67,1032.93,384.11ZM683,496.81q43.74,0,87.48,0c15.55,0,25.32-9.72,25.33-25.21q0-87.48,0-175c0-15.83-9.68-25.46-25.59-25.46H595.77c-15.88,0-25.57,9.64-25.58,25.46q0,87.23,0,174.45c0,16.18,9.59,25.7,25.84,25.71Z' transform='translate(-183.1 115.9)'/%3E%3Cpath class='cls-3' d='M683,496.81H596c-16.25,0-25.84-9.53-25.84-25.71q0-87.23,0-174.45c0-15.82,9.7-25.46,25.58-25.46H770.22c15.91,0,25.59,9.63,25.59,25.46q0,87.47,0,175c0,15.49-9.78,25.2-25.33,25.21Q726.74,496.84,683,496.81Z' transform='translate(-183.1 115.9)'/%3E%3C/svg%3E`;
    case "text":
        return t = (.1 * e).toFixed(2),
        `data:image/svg+xml,%3Csvg width='${e}' height='${t}' xmlns='http://www.w3.org/2000/svg' viewBox='0 0 528.15 53.64'%3E%3Cdefs%3E%3Cstyle%3E.cls-1%7Bfill:%230052ff;%7D%3C/style%3E%3C/defs%3E%3Ctitle%3ECoinbase_Wordmark_SubBrands_ALL%3C/title%3E%3Cpath class='cls-1' d='M164.45,15a15,15,0,0,0-11.74,5.4V0h-8.64V52.92h8.5V48a15,15,0,0,0,11.88,5.62c10.37,0,18.21-8.21,18.21-19.3S174.67,15,164.45,15Zm-1.3,30.67c-6.19,0-10.73-4.83-10.73-11.31S157,23,163.22,23s10.66,4.82,10.66,11.37S169.34,45.65,163.15,45.65Zm83.31-14.91-6.34-.93c-3-.43-5.18-1.44-5.18-3.82,0-2.59,2.8-3.89,6.62-3.89,4.18,0,6.84,1.8,7.42,4.76h8.35c-.94-7.49-6.7-11.88-15.55-11.88-9.15,0-15.2,4.68-15.2,11.3,0,6.34,4,10,12,11.16l6.33.94c3.1.43,4.83,1.65,4.83,4,0,2.95-3,4.17-7.2,4.17-5.12,0-8-2.09-8.43-5.25h-8.49c.79,7.27,6.48,12.38,16.84,12.38,9.44,0,15.7-4.32,15.7-11.74C258.12,35.28,253.58,31.82,246.46,30.74Zm-27.65-2.3c0-8.06-4.9-13.46-15.27-13.46-9.79,0-15.26,5-16.34,12.6h8.57c.43-3,2.73-5.4,7.63-5.4,4.39,0,6.55,1.94,6.55,4.32,0,3.09-4,3.88-8.85,4.39-6.63.72-14.84,3-14.84,11.66,0,6.7,5,11,12.89,11,6.19,0,10.08-2.59,12-6.7.28,3.67,3,6.05,6.84,6.05h5v-7.7h-4.25Zm-8.5,9.36c0,5-4.32,8.64-9.57,8.64-3.24,0-6-1.37-6-4.25,0-3.67,4.39-4.68,8.42-5.11s6-1.22,7.13-2.88ZM281.09,15c-11.09,0-19.23,8.35-19.23,19.36,0,11.6,8.72,19.3,19.37,19.3,9,0,16.06-5.33,17.86-12.89h-9c-1.3,3.31-4.47,5.19-8.71,5.19-5.55,0-9.72-3.46-10.66-9.51H299.3V33.12C299.3,22.46,291.53,15,281.09,15Zm-9.87,15.26c1.37-5.18,5.26-7.7,9.72-7.7,4.9,0,8.64,2.8,9.51,7.7ZM19.3,23a9.84,9.84,0,0,1,9.5,7h9.14c-1.65-8.93-9-15-18.57-15A19,19,0,0,0,0,34.34c0,11.09,8.28,19.3,19.37,19.3,9.36,0,16.85-6,18.5-15H28.8a9.75,9.75,0,0,1-9.43,7.06c-6.27,0-10.66-4.83-10.66-11.31S13,23,19.3,23Zm41.11-8A19,19,0,0,0,41,34.34c0,11.09,8.28,19.3,19.37,19.3A19,19,0,0,0,79.92,34.27C79.92,23.33,71.64,15,60.41,15Zm.07,30.67c-6.19,0-10.73-4.83-10.73-11.31S54.22,23,60.41,23s10.8,4.89,10.8,11.37S66.67,45.65,60.48,45.65ZM123.41,15c-5.62,0-9.29,2.3-11.45,5.54V15.7h-8.57V52.92H112V32.69C112,27,115.63,23,121,23c5,0,8.06,3.53,8.06,8.64V52.92h8.64V31C137.66,21.6,132.84,15,123.41,15ZM92,.36a5.36,5.36,0,0,0-5.55,5.47,5.55,5.55,0,0,0,11.09,0A5.35,5.35,0,0,0,92,.36Zm-9.72,23h5.4V52.92h8.64V15.7h-14Zm298.17-7.7L366.2,52.92H372L375.29,44H392l3.33,8.88h6L386.87,15.7ZM377,39.23l6.45-17.56h.1l6.56,17.56ZM362.66,15.7l-7.88,29h-.11l-8.14-29H341l-8,28.93h-.1l-8-28.87H319L329.82,53h5.45l8.19-29.24h.11L352,53h5.66L368.1,15.7Zm135.25,0v4.86h12.32V52.92h5.6V20.56h12.32V15.7ZM467.82,52.92h25.54V48.06H473.43v-12h18.35V31.35H473.43V20.56h19.93V15.7H467.82ZM443,15.7h-5.6V52.92h24.32V48.06H443Zm-30.45,0h-5.61V52.92h24.32V48.06H412.52Z'/%3E%3C/svg%3E`;
    case "textWithLogo":
        return t = (.25 * e).toFixed(2),
        `data:image/svg+xml,%3Csvg width='${e}' height='${t}' xmlns='http://www.w3.org/2000/svg' viewBox='0 0 308.44 77.61'%3E%3Cdefs%3E%3Cstyle%3E.cls-1%7Bfill:%230052ff;%7D%3C/style%3E%3C/defs%3E%3Cpath class='cls-1' d='M142.94,20.2l-7.88,29H135l-8.15-29h-5.55l-8,28.93h-.11l-8-28.87H99.27l10.84,37.27h5.44l8.2-29.24h.1l8.41,29.24h5.66L148.39,20.2Zm17.82,0L146.48,57.42h5.82l3.28-8.88h16.65l3.34,8.88h6L167.16,20.2Zm-3.44,23.52,6.45-17.55h.11l6.56,17.55ZM278.2,20.2v4.86h12.32V57.42h5.6V25.06h12.32V20.2ZM248.11,57.42h25.54V52.55H253.71V40.61h18.35V35.85H253.71V25.06h19.94V20.2H248.11ZM223.26,20.2h-5.61V57.42H242V52.55H223.26Zm-30.46,0h-5.6V57.42h24.32V52.55H192.8Zm-154,38A19.41,19.41,0,1,1,57.92,35.57H77.47a38.81,38.81,0,1,0,0,6.47H57.92A19.39,19.39,0,0,1,38.81,58.21Z'/%3E%3C/svg%3E`;
    case "textLight":
        return t = (.1 * e).toFixed(2),
        `data:image/svg+xml,%3Csvg width='${e}' height='${t}' xmlns='http://www.w3.org/2000/svg' viewBox='0 0 528.15 53.64'%3E%3Cdefs%3E%3Cstyle%3E.cls-1%7Bfill:%23fefefe;%7D%3C/style%3E%3C/defs%3E%3Ctitle%3ECoinbase_Wordmark_SubBrands_ALL%3C/title%3E%3Cpath class='cls-1' d='M164.45,15a15,15,0,0,0-11.74,5.4V0h-8.64V52.92h8.5V48a15,15,0,0,0,11.88,5.62c10.37,0,18.21-8.21,18.21-19.3S174.67,15,164.45,15Zm-1.3,30.67c-6.19,0-10.73-4.83-10.73-11.31S157,23,163.22,23s10.66,4.82,10.66,11.37S169.34,45.65,163.15,45.65Zm83.31-14.91-6.34-.93c-3-.43-5.18-1.44-5.18-3.82,0-2.59,2.8-3.89,6.62-3.89,4.18,0,6.84,1.8,7.42,4.76h8.35c-.94-7.49-6.7-11.88-15.55-11.88-9.15,0-15.2,4.68-15.2,11.3,0,6.34,4,10,12,11.16l6.33.94c3.1.43,4.83,1.65,4.83,4,0,2.95-3,4.17-7.2,4.17-5.12,0-8-2.09-8.43-5.25h-8.49c.79,7.27,6.48,12.38,16.84,12.38,9.44,0,15.7-4.32,15.7-11.74C258.12,35.28,253.58,31.82,246.46,30.74Zm-27.65-2.3c0-8.06-4.9-13.46-15.27-13.46-9.79,0-15.26,5-16.34,12.6h8.57c.43-3,2.73-5.4,7.63-5.4,4.39,0,6.55,1.94,6.55,4.32,0,3.09-4,3.88-8.85,4.39-6.63.72-14.84,3-14.84,11.66,0,6.7,5,11,12.89,11,6.19,0,10.08-2.59,12-6.7.28,3.67,3,6.05,6.84,6.05h5v-7.7h-4.25Zm-8.5,9.36c0,5-4.32,8.64-9.57,8.64-3.24,0-6-1.37-6-4.25,0-3.67,4.39-4.68,8.42-5.11s6-1.22,7.13-2.88ZM281.09,15c-11.09,0-19.23,8.35-19.23,19.36,0,11.6,8.72,19.3,19.37,19.3,9,0,16.06-5.33,17.86-12.89h-9c-1.3,3.31-4.47,5.19-8.71,5.19-5.55,0-9.72-3.46-10.66-9.51H299.3V33.12C299.3,22.46,291.53,15,281.09,15Zm-9.87,15.26c1.37-5.18,5.26-7.7,9.72-7.7,4.9,0,8.64,2.8,9.51,7.7ZM19.3,23a9.84,9.84,0,0,1,9.5,7h9.14c-1.65-8.93-9-15-18.57-15A19,19,0,0,0,0,34.34c0,11.09,8.28,19.3,19.37,19.3,9.36,0,16.85-6,18.5-15H28.8a9.75,9.75,0,0,1-9.43,7.06c-6.27,0-10.66-4.83-10.66-11.31S13,23,19.3,23Zm41.11-8A19,19,0,0,0,41,34.34c0,11.09,8.28,19.3,19.37,19.3A19,19,0,0,0,79.92,34.27C79.92,23.33,71.64,15,60.41,15Zm.07,30.67c-6.19,0-10.73-4.83-10.73-11.31S54.22,23,60.41,23s10.8,4.89,10.8,11.37S66.67,45.65,60.48,45.65ZM123.41,15c-5.62,0-9.29,2.3-11.45,5.54V15.7h-8.57V52.92H112V32.69C112,27,115.63,23,121,23c5,0,8.06,3.53,8.06,8.64V52.92h8.64V31C137.66,21.6,132.84,15,123.41,15ZM92,.36a5.36,5.36,0,0,0-5.55,5.47,5.55,5.55,0,0,0,11.09,0A5.35,5.35,0,0,0,92,.36Zm-9.72,23h5.4V52.92h8.64V15.7h-14Zm298.17-7.7L366.2,52.92H372L375.29,44H392l3.33,8.88h6L386.87,15.7ZM377,39.23l6.45-17.56h.1l6.56,17.56ZM362.66,15.7l-7.88,29h-.11l-8.14-29H341l-8,28.93h-.1l-8-28.87H319L329.82,53h5.45l8.19-29.24h.11L352,53h5.66L368.1,15.7Zm135.25,0v4.86h12.32V52.92h5.6V20.56h12.32V15.7ZM467.82,52.92h25.54V48.06H473.43v-12h18.35V31.35H473.43V20.56h19.93V15.7H467.82ZM443,15.7h-5.6V52.92h24.32V48.06H443Zm-30.45,0h-5.61V52.92h24.32V48.06H412.52Z'/%3E%3C/svg%3E`;
    case "textWithLogoLight":
        return t = (.25 * e).toFixed(2),
        `data:image/svg+xml,%3Csvg width='${e}' height='${t}' xmlns='http://www.w3.org/2000/svg' viewBox='0 0 308.44 77.61'%3E%3Cdefs%3E%3Cstyle%3E.cls-1%7Bfill:%23fefefe;%7D%3C/style%3E%3C/defs%3E%3Cpath class='cls-1' d='M142.94,20.2l-7.88,29H135l-8.15-29h-5.55l-8,28.93h-.11l-8-28.87H99.27l10.84,37.27h5.44l8.2-29.24h.1l8.41,29.24h5.66L148.39,20.2Zm17.82,0L146.48,57.42h5.82l3.28-8.88h16.65l3.34,8.88h6L167.16,20.2Zm-3.44,23.52,6.45-17.55h.11l6.56,17.55ZM278.2,20.2v4.86h12.32V57.42h5.6V25.06h12.32V20.2ZM248.11,57.42h25.54V52.55H253.71V40.61h18.35V35.85H253.71V25.06h19.94V20.2H248.11ZM223.26,20.2h-5.61V57.42H242V52.55H223.26Zm-30.46,0h-5.6V57.42h24.32V52.55H192.8Zm-154,38A19.41,19.41,0,1,1,57.92,35.57H77.47a38.81,38.81,0,1,0,0,6.47H57.92A19.39,19.39,0,0,1,38.81,58.21Z'/%3E%3C/svg%3E`;
    default:
        return t = e,
        `data:image/svg+xml,%3Csvg width='${e}' height='${t}' viewBox='0 0 1024 1024' fill='none' xmlns='http://www.w3.org/2000/svg'%3E %3Crect width='1024' height='1024' fill='%230052FF'/%3E %3Cpath fill-rule='evenodd' clip-rule='evenodd' d='M152 512C152 710.823 313.177 872 512 872C710.823 872 872 710.823 872 512C872 313.177 710.823 152 512 152C313.177 152 152 313.177 152 512ZM420 396C406.745 396 396 406.745 396 420V604C396 617.255 406.745 628 420 628H604C617.255 628 628 617.255 628 604V420C628 406.745 617.255 396 604 396H420Z' fill='white'/%3E %3C/svg%3E `
    }
}
;
fe.walletLogo = cr;
var me = {}
  , O = {}
  , U = {};
Object.defineProperty(U, "__esModule", {
    value: !0
});
U.errorValues = U.standardErrorCodes = void 0;
U.standardErrorCodes = {
    rpc: {
        invalidInput: -32e3,
        resourceNotFound: -32001,
        resourceUnavailable: -32002,
        transactionRejected: -32003,
        methodNotSupported: -32004,
        limitExceeded: -32005,
        parse: -32700,
        invalidRequest: -32600,
        methodNotFound: -32601,
        invalidParams: -32602,
        internal: -32603
    },
    provider: {
        userRejectedRequest: 4001,
        unauthorized: 4100,
        unsupportedMethod: 4200,
        disconnected: 4900,
        chainDisconnected: 4901,
        unsupportedChain: 4902
    }
};
U.errorValues = {
    "-32700": {
        standard: "JSON RPC 2.0",
        message: "Invalid JSON was received by the server. An error occurred on the server while parsing the JSON text."
    },
    "-32600": {
        standard: "JSON RPC 2.0",
        message: "The JSON sent is not a valid Request object."
    },
    "-32601": {
        standard: "JSON RPC 2.0",
        message: "The method does not exist / is not available."
    },
    "-32602": {
        standard: "JSON RPC 2.0",
        message: "Invalid method parameter(s)."
    },
    "-32603": {
        standard: "JSON RPC 2.0",
        message: "Internal JSON-RPC error."
    },
    "-32000": {
        standard: "EIP-1474",
        message: "Invalid input."
    },
    "-32001": {
        standard: "EIP-1474",
        message: "Resource not found."
    },
    "-32002": {
        standard: "EIP-1474",
        message: "Resource unavailable."
    },
    "-32003": {
        standard: "EIP-1474",
        message: "Transaction rejected."
    },
    "-32004": {
        standard: "EIP-1474",
        message: "Method not supported."
    },
    "-32005": {
        standard: "EIP-1474",
        message: "Request limit exceeded."
    },
    4001: {
        standard: "EIP-1193",
        message: "User rejected the request."
    },
    4100: {
        standard: "EIP-1193",
        message: "The requested account and/or method has not been authorized by the user."
    },
    4200: {
        standard: "EIP-1193",
        message: "The requested method is not supported by this Ethereum provider."
    },
    4900: {
        standard: "EIP-1193",
        message: "The provider is disconnected from all chains."
    },
    4901: {
        standard: "EIP-1193",
        message: "The provider is disconnected from the specified chain."
    },
    4902: {
        standard: "EIP-3085",
        message: "Unrecognized chain ID."
    }
};
var be = {}
  , Fe = {};
(function(r) {
    Object.defineProperty(r, "__esModule", {
        value: !0
    }),
    r.serialize = r.getErrorCode = r.isValidCode = r.getMessageFromCode = r.JSON_RPC_SERVER_ERROR_MESSAGE = void 0;
    const e = U
      , t = "Unspecified error message.";
    r.JSON_RPC_SERVER_ERROR_MESSAGE = "Unspecified server error.";
    function n(d, p=t) {
        if (d && Number.isInteger(d)) {
            const m = d.toString();
            if (h(e.errorValues, m))
                return e.errorValues[m].message;
            if (c(d))
                return r.JSON_RPC_SERVER_ERROR_MESSAGE
        }
        return p
    }
    r.getMessageFromCode = n;
    function s(d) {
        if (!Number.isInteger(d))
            return !1;
        const p = d.toString();
        return !!(e.errorValues[p] || c(d))
    }
    r.isValidCode = s;
    function i(d) {
        var p;
        if (typeof d == "number")
            return d;
        if (a(d))
            return (p = d.code) !== null && p !== void 0 ? p : d.errorCode
    }
    r.getErrorCode = i;
    function a(d) {
        return typeof d == "object" && d !== null && (typeof d.code == "number" || typeof d.errorCode == "number")
    }
    function o(d, {shouldIncludeStack: p=!1}={}) {
        const m = {};
        if (d && typeof d == "object" && !Array.isArray(d) && h(d, "code") && s(d.code)) {
            const B = d;
            m.code = B.code,
            B.message && typeof B.message == "string" ? (m.message = B.message,
            h(B, "data") && (m.data = B.data)) : (m.message = n(m.code),
            m.data = {
                originalError: l(d)
            })
        } else
            m.code = e.standardErrorCodes.rpc.internal,
            m.message = f(d, "message") ? d.message : t,
            m.data = {
                originalError: l(d)
            };
        return p && (m.stack = f(d, "stack") ? d.stack : void 0),
        m
    }
    r.serialize = o;
    function c(d) {
        return d >= -32099 && d <= -32e3
    }
    function l(d) {
        return d && typeof d == "object" && !Array.isArray(d) ? Object.assign({}, d) : d
    }
    function h(d, p) {
        return Object.prototype.hasOwnProperty.call(d, p)
    }
    function f(d, p) {
        return typeof d == "object" && d !== null && p in d && typeof d[p] == "string"
    }
}
)(Fe);
Object.defineProperty(be, "__esModule", {
    value: !0
});
be.standardErrors = void 0;
const v = U
  , St = Fe;
be.standardErrors = {
    rpc: {
        parse: r => C(v.standardErrorCodes.rpc.parse, r),
        invalidRequest: r => C(v.standardErrorCodes.rpc.invalidRequest, r),
        invalidParams: r => C(v.standardErrorCodes.rpc.invalidParams, r),
        methodNotFound: r => C(v.standardErrorCodes.rpc.methodNotFound, r),
        internal: r => C(v.standardErrorCodes.rpc.internal, r),
        server: r => {
            if (!r || typeof r != "object" || Array.isArray(r))
                throw new Error("Ethereum RPC Server errors must provide single object argument.");
            const {code: e} = r;
            if (!Number.isInteger(e) || e > -32005 || e < -32099)
                throw new Error('"code" must be an integer such that: -32099 <= code <= -32005');
            return C(e, r)
        }
        ,
        invalidInput: r => C(v.standardErrorCodes.rpc.invalidInput, r),
        resourceNotFound: r => C(v.standardErrorCodes.rpc.resourceNotFound, r),
        resourceUnavailable: r => C(v.standardErrorCodes.rpc.resourceUnavailable, r),
        transactionRejected: r => C(v.standardErrorCodes.rpc.transactionRejected, r),
        methodNotSupported: r => C(v.standardErrorCodes.rpc.methodNotSupported, r),
        limitExceeded: r => C(v.standardErrorCodes.rpc.limitExceeded, r)
    },
    provider: {
        userRejectedRequest: r => $(v.standardErrorCodes.provider.userRejectedRequest, r),
        unauthorized: r => $(v.standardErrorCodes.provider.unauthorized, r),
        unsupportedMethod: r => $(v.standardErrorCodes.provider.unsupportedMethod, r),
        disconnected: r => $(v.standardErrorCodes.provider.disconnected, r),
        chainDisconnected: r => $(v.standardErrorCodes.provider.chainDisconnected, r),
        unsupportedChain: r => $(v.standardErrorCodes.provider.unsupportedChain, r),
        custom: r => {
            if (!r || typeof r != "object" || Array.isArray(r))
                throw new Error("Ethereum Provider custom errors must provide single object argument.");
            const {code: e, message: t, data: n} = r;
            if (!t || typeof t != "string")
                throw new Error('"message" must be a nonempty string');
            return new It(e,t,n)
        }
    }
};
function C(r, e) {
    const [t,n] = Ct(e);
    return new kt(r,t || (0,
    St.getMessageFromCode)(r),n)
}
function $(r, e) {
    const [t,n] = Ct(e);
    return new It(r,t || (0,
    St.getMessageFromCode)(r),n)
}
function Ct(r) {
    if (r) {
        if (typeof r == "string")
            return [r];
        if (typeof r == "object" && !Array.isArray(r)) {
            const {message: e, data: t} = r;
            if (e && typeof e != "string")
                throw new Error("Must specify string message.");
            return [e || void 0, t]
        }
    }
    return []
}
class kt extends Error {
    constructor(e, t, n) {
        if (!Number.isInteger(e))
            throw new Error('"code" must be an integer.');
        if (!t || typeof t != "string")
            throw new Error('"message" must be a nonempty string.');
        super(t),
        this.code = e,
        n !== void 0 && (this.data = n)
    }
}
class It extends kt {
    constructor(e, t, n) {
        if (!dr(e))
            throw new Error('"code" must be an integer such that: 1000 <= code <= 4999');
        super(e, t, n)
    }
}
function dr(r) {
    return Number.isInteger(r) && r >= 1e3 && r <= 4999
}
(function(r) {
    Object.defineProperty(r, "__esModule", {
        value: !0
    }),
    r.standardErrors = r.standardErrorCodes = void 0;
    var e = U;
    Object.defineProperty(r, "standardErrorCodes", {
        enumerable: !0,
        get: function() {
            return e.standardErrorCodes
        }
    });
    var t = be;
    Object.defineProperty(r, "standardErrors", {
        enumerable: !0,
        get: function() {
            return t.standardErrors
        }
    })
}
)(O);
var ye = {}
  , Q = {};
Object.defineProperty(Q, "__esModule", {
    value: !0
});
Q.isErrorResponse = void 0;
function lr(r) {
    return r.errorMessage !== void 0
}
Q.isErrorResponse = lr;
var K = {};
Object.defineProperty(K, "__esModule", {
    value: !0
});
K.LIB_VERSION = void 0;
K.LIB_VERSION = "4.0.2";
Object.defineProperty(ye, "__esModule", {
    value: !0
});
ye.serializeError = void 0;
const ur = Q
  , hr = K
  , gr = U
  , pr = Fe;
function fr(r, e) {
    const t = (0,
    pr.serialize)(mr(r), {
        shouldIncludeStack: !0
    })
      , n = new URL("https://docs.cloud.coinbase.com/wallet-sdk/docs/errors");
    n.searchParams.set("version", hr.LIB_VERSION),
    n.searchParams.set("code", t.code.toString());
    const s = br(t.data, e);
    return s && n.searchParams.set("method", s),
    n.searchParams.set("message", t.message),
    Object.assign(Object.assign({}, t), {
        docUrl: n.href
    })
}
ye.serializeError = fr;
function mr(r) {
    return typeof r == "string" ? {
        message: r,
        code: gr.standardErrorCodes.rpc.internal
    } : (0,
    ur.isErrorResponse)(r) ? Object.assign(Object.assign({}, r), {
        message: r.errorMessage,
        code: r.errorCode,
        data: {
            method: r.method
        }
    }) : r
}
function br(r, e) {
    const t = r == null ? void 0 : r.method;
    if (t)
        return t;
    if (e !== void 0) {
        if (typeof e == "string")
            return e;
        if (Array.isArray(e)) {
            if (e.length > 0)
                return e[0].method
        } else
            return e.method
    }
}
var _ = {};
Object.defineProperty(_, "__esModule", {
    value: !0
});
_.RegExpString = _.IntNumber = _.BigIntString = _.AddressString = _.HexString = _.OpaqueType = void 0;
function te() {
    return r => r
}
_.OpaqueType = te;
_.HexString = te();
_.AddressString = te();
_.BigIntString = te();
function yr(r) {
    return Math.floor(r)
}
_.IntNumber = yr;
_.RegExpString = te();
var u = {};
Object.defineProperty(u, "__esModule", {
    value: !0
});
u.areAddressArraysEqual = u.getFavicon = u.range = u.isBigNumber = u.ensureParsedJSONObject = u.ensureBigInt = u.ensureRegExpString = u.ensureIntNumber = u.ensureBuffer = u.ensureAddressString = u.ensureEvenLengthHexString = u.ensureHexString = u.isHexString = u.prepend0x = u.strip0x = u.has0xPrefix = u.hexStringFromIntNumber = u.intNumberFromHexString = u.bigIntStringFromBigInt = u.hexStringFromBuffer = u.hexStringToUint8Array = u.uint8ArrayToHex = u.randomBytesHex = void 0;
const q = O
  , I = _
  , Mt = /^[0-9]*$/
  , Lt = /^[a-f0-9]*$/;
function wr(r) {
    return At(crypto.getRandomValues(new Uint8Array(r)))
}
u.randomBytesHex = wr;
function At(r) {
    return [...r].map(e => e.toString(16).padStart(2, "0")).join("")
}
u.uint8ArrayToHex = At;
function vr(r) {
    return new Uint8Array(r.match(/.{1,2}/g).map(e => parseInt(e, 16)))
}
u.hexStringToUint8Array = vr;
function _r(r, e=!1) {
    const t = r.toString("hex");
    return (0,
    I.HexString)(e ? `0x${t}` : t)
}
u.hexStringFromBuffer = _r;
function Er(r) {
    return (0,
    I.BigIntString)(r.toString(10))
}
u.bigIntStringFromBigInt = Er;
function Sr(r) {
    return (0,
    I.IntNumber)(Number(BigInt(ne(r, !0))))
}
u.intNumberFromHexString = Sr;
function Cr(r) {
    return (0,
    I.HexString)(`0x${BigInt(r).toString(16)}`)
}
u.hexStringFromIntNumber = Cr;
function Ve(r) {
    return r.startsWith("0x") || r.startsWith("0X")
}
u.has0xPrefix = Ve;
function we(r) {
    return Ve(r) ? r.slice(2) : r
}
u.strip0x = we;
function Rt(r) {
    return Ve(r) ? `0x${r.slice(2)}` : `0x${r}`
}
u.prepend0x = Rt;
function re(r) {
    if (typeof r != "string")
        return !1;
    const e = we(r).toLowerCase();
    return Lt.test(e)
}
u.isHexString = re;
function xt(r, e=!1) {
    if (typeof r == "string") {
        const t = we(r).toLowerCase();
        if (Lt.test(t))
            return (0,
            I.HexString)(e ? `0x${t}` : t)
    }
    throw q.standardErrors.rpc.invalidParams(`"${String(r)}" is not a hexadecimal string`)
}
u.ensureHexString = xt;
function ne(r, e=!1) {
    let t = xt(r, !1);
    return t.length % 2 === 1 && (t = (0,
    I.HexString)(`0${t}`)),
    e ? (0,
    I.HexString)(`0x${t}`) : t
}
u.ensureEvenLengthHexString = ne;
function kr(r) {
    if (typeof r == "string") {
        const e = we(r).toLowerCase();
        if (re(e) && e.length === 40)
            return (0,
            I.AddressString)(Rt(e))
    }
    throw q.standardErrors.rpc.invalidParams(`Invalid Ethereum address: ${String(r)}`)
}
u.ensureAddressString = kr;
function Ir(r) {
    if (Buffer.isBuffer(r))
        return r;
    if (typeof r == "string") {
        if (re(r)) {
            const e = ne(r, !1);
            return Buffer.from(e, "hex")
        }
        return Buffer.from(r, "utf8")
    }
    throw q.standardErrors.rpc.invalidParams(`Not binary data: ${String(r)}`)
}
u.ensureBuffer = Ir;
function Pt(r) {
    if (typeof r == "number" && Number.isInteger(r))
        return (0,
        I.IntNumber)(r);
    if (typeof r == "string") {
        if (Mt.test(r))
            return (0,
            I.IntNumber)(Number(r));
        if (re(r))
            return (0,
            I.IntNumber)(Number(BigInt(ne(r, !0))))
    }
    throw q.standardErrors.rpc.invalidParams(`Not an integer: ${String(r)}`)
}
u.ensureIntNumber = Pt;
function Mr(r) {
    if (r instanceof RegExp)
        return (0,
        I.RegExpString)(r.toString());
    throw q.standardErrors.rpc.invalidParams(`Not a RegExp: ${String(r)}`)
}
u.ensureRegExpString = Mr;
function Lr(r) {
    if (r !== null && (typeof r == "bigint" || Nt(r)))
        return BigInt(r.toString(10));
    if (typeof r == "number")
        return BigInt(Pt(r));
    if (typeof r == "string") {
        if (Mt.test(r))
            return BigInt(r);
        if (re(r))
            return BigInt(ne(r, !0))
    }
    throw q.standardErrors.rpc.invalidParams(`Not an integer: ${String(r)}`)
}
u.ensureBigInt = Lr;
function Ar(r) {
    if (typeof r == "string")
        return JSON.parse(r);
    if (typeof r == "object")
        return r;
    throw q.standardErrors.rpc.invalidParams(`Not a JSON string or an object: ${String(r)}`)
}
u.ensureParsedJSONObject = Ar;
function Nt(r) {
    if (r == null || typeof r.constructor != "function")
        return !1;
    const {constructor: e} = r;
    return typeof e.config == "function" && typeof e.EUCLID == "number"
}
u.isBigNumber = Nt;
function Rr(r, e) {
    return Array.from({
        length: e - r
    }, (t, n) => r + n)
}
u.range = Rr;
function xr() {
    const r = document.querySelector('link[sizes="192x192"]') || document.querySelector('link[sizes="180x180"]') || document.querySelector('link[rel="icon"]') || document.querySelector('link[rel="shortcut icon"]')
      , {protocol: e, host: t} = document.location
      , n = r ? r.getAttribute("href") : null;
    return !n || n.startsWith("javascript:") || n.startsWith("vbscript:") ? null : n.startsWith("http://") || n.startsWith("https://") || n.startsWith("data:") ? n : n.startsWith("//") ? e + n : `${e}//${t}${n}`
}
u.getFavicon = xr;
function Pr(r, e) {
    return r.length === e.length && r.every( (t, n) => t === e[n])
}
u.areAddressArraysEqual = Pr;
var P = {}
  , ve = {}
  , _e = {}
  , y = {};
Object.defineProperty(y, "__esModule", {
    value: !0
});
y.decryptContent = y.encryptContent = y.importKeyFromHexString = y.exportKeyToHexString = y.decrypt = y.encrypt = y.deriveSharedSecret = y.generateKeyPair = void 0;
const Tt = u;
async function Nr() {
    return crypto.subtle.generateKey({
        name: "ECDH",
        namedCurve: "P-256"
    }, !0, ["deriveKey"])
}
y.generateKeyPair = Nr;
async function Tr(r, e) {
    return crypto.subtle.deriveKey({
        name: "ECDH",
        public: e
    }, r, {
        name: "AES-GCM",
        length: 256
    }, !1, ["encrypt", "decrypt"])
}
y.deriveSharedSecret = Tr;
async function Ot(r, e) {
    const t = crypto.getRandomValues(new Uint8Array(12))
      , n = await crypto.subtle.encrypt({
        name: "AES-GCM",
        iv: t
    }, r, new TextEncoder().encode(e));
    return {
        iv: t,
        cipherText: n
    }
}
y.encrypt = Ot;
async function jt(r, {iv: e, cipherText: t}) {
    const n = await crypto.subtle.decrypt({
        name: "AES-GCM",
        iv: e
    }, r, t);
    return new TextDecoder().decode(n)
}
y.decrypt = jt;
function Dt(r) {
    switch (r) {
    case "public":
        return "spki";
    case "private":
        return "pkcs8"
    }
}
async function Or(r, e) {
    const t = Dt(r)
      , n = await crypto.subtle.exportKey(t, e);
    return (0,
    Tt.uint8ArrayToHex)(new Uint8Array(n))
}
y.exportKeyToHexString = Or;
async function jr(r, e) {
    const t = Dt(r)
      , n = (0,
    Tt.hexStringToUint8Array)(e).buffer;
    return await crypto.subtle.importKey(t, n, {
        name: "ECDH",
        namedCurve: "P-256"
    }, !0, r === "private" ? ["deriveKey"] : [])
}
y.importKeyFromHexString = jr;
async function Dr(r, e) {
    const t = JSON.stringify(r, (n, s) => {
        if (!(s instanceof Error))
            return s;
        const i = s;
        return Object.assign(Object.assign({}, i.code ? {
            code: i.code
        } : {}), {
            message: i.message
        })
    }
    );
    return Ot(e, t)
}
y.encryptContent = Dr;
async function Wr(r, e) {
    return JSON.parse(await jt(e, r))
}
y.decryptContent = Wr;
var j = {};
Object.defineProperty(j, "__esModule", {
    value: !0
});
j.ScopedLocalStorage = void 0;
class pe {
    constructor(e, t) {
        this.scope = e,
        this.module = t
    }
    setItem(e, t) {
        localStorage.setItem(this.scopedKey(e), t)
    }
    getItem(e) {
        return localStorage.getItem(this.scopedKey(e))
    }
    removeItem(e) {
        localStorage.removeItem(this.scopedKey(e))
    }
    clear() {
        const e = this.scopedKey("")
          , t = [];
        for (let n = 0; n < localStorage.length; n++) {
            const s = localStorage.key(n);
            typeof s == "string" && s.startsWith(e) && t.push(s)
        }
        t.forEach(n => localStorage.removeItem(n))
    }
    scopedKey(e) {
        return `-${this.scope}${this.module ? `:${this.module}` : ""}:${e}`
    }
    static clearAll() {
        new pe("CBWSDK").clear(),
        new pe("walletlink").clear()
    }
}
j.ScopedLocalStorage = pe;
Object.defineProperty(_e, "__esModule", {
    value: !0
});
_e.SCWKeyManager = void 0;
const ae = y
  , Ur = j
  , je = {
    storageKey: "ownPrivateKey",
    keyType: "private"
}
  , De = {
    storageKey: "ownPublicKey",
    keyType: "public"
}
  , We = {
    storageKey: "peerPublicKey",
    keyType: "public"
};
class Br {
    constructor() {
        this.storage = new Ur.ScopedLocalStorage("CBWSDK","SCWKeyManager"),
        this.ownPrivateKey = null,
        this.ownPublicKey = null,
        this.peerPublicKey = null,
        this.sharedSecret = null
    }
    async getOwnPublicKey() {
        return await this.loadKeysIfNeeded(),
        this.ownPublicKey
    }
    async getSharedSecret() {
        return await this.loadKeysIfNeeded(),
        this.sharedSecret
    }
    async setPeerPublicKey(e) {
        this.sharedSecret = null,
        this.peerPublicKey = e,
        await this.storeKey(We, e),
        await this.loadKeysIfNeeded()
    }
    async clear() {
        this.ownPrivateKey = null,
        this.ownPublicKey = null,
        this.peerPublicKey = null,
        this.sharedSecret = null,
        this.storage.removeItem(De.storageKey),
        this.storage.removeItem(je.storageKey),
        this.storage.removeItem(We.storageKey)
    }
    async generateKeyPair() {
        const e = await (0,
        ae.generateKeyPair)();
        this.ownPrivateKey = e.privateKey,
        this.ownPublicKey = e.publicKey,
        await this.storeKey(je, e.privateKey),
        await this.storeKey(De, e.publicKey)
    }
    async loadKeysIfNeeded() {
        if (this.ownPrivateKey === null && (this.ownPrivateKey = await this.loadKey(je)),
        this.ownPublicKey === null && (this.ownPublicKey = await this.loadKey(De)),
        (this.ownPrivateKey === null || this.ownPublicKey === null) && await this.generateKeyPair(),
        this.peerPublicKey === null && (this.peerPublicKey = await this.loadKey(We)),
        this.sharedSecret === null) {
            if (this.ownPrivateKey === null || this.peerPublicKey === null)
                return;
            this.sharedSecret = await (0,
            ae.deriveSharedSecret)(this.ownPrivateKey, this.peerPublicKey)
        }
    }
    async loadKey(e) {
        const t = this.storage.getItem(e.storageKey);
        return t ? (0,
        ae.importKeyFromHexString)(e.keyType, t) : null
    }
    async storeKey(e, t) {
        const n = await (0,
        ae.exportKeyToHexString)(e.keyType, t);
        this.storage.setItem(e.storageKey, n)
    }
}
_e.SCWKeyManager = Br;
var Ee = {};
Object.defineProperty(Ee, "__esModule", {
    value: !0
});
Ee.SCWStateManager = void 0;
const Hr = j
  , Xe = "accounts"
  , et = "activeChain"
  , tt = "availableChains"
  , rt = "walletCapabilities";
class Kr {
    get accounts() {
        return this._accounts
    }
    get activeChain() {
        return this._activeChain
    }
    get walletCapabilities() {
        return this._walletCapabilities
    }
    constructor(e) {
        var t, n;
        this.storage = new Hr.ScopedLocalStorage("CBWSDK","SCWStateManager"),
        this.updateListener = e.updateListener,
        this.availableChains = this.loadItemFromStorage(tt),
        this._walletCapabilities = this.loadItemFromStorage(rt);
        const s = this.loadItemFromStorage(Xe)
          , i = this.loadItemFromStorage(et);
        s && this.updateListener.onAccountsUpdate({
            accounts: s,
            source: "storage"
        }),
        i && this.updateListener.onChainUpdate({
            chain: i,
            source: "storage"
        }),
        this._accounts = s || [],
        this._activeChain = i || {
            id: (n = (t = e.appChainIds) === null || t === void 0 ? void 0 : t[0]) !== null && n !== void 0 ? n : 1
        }
    }
    updateAccounts(e) {
        this._accounts = e,
        this.storeItemToStorage(Xe, e),
        this.updateListener.onAccountsUpdate({
            accounts: e,
            source: "wallet"
        })
    }
    switchChain(e) {
        var t;
        const n = (t = this.availableChains) === null || t === void 0 ? void 0 : t.find(s => s.id === e);
        return n ? (n === this._activeChain || (this._activeChain = n,
        this.storeItemToStorage(et, n),
        this.updateListener.onChainUpdate({
            chain: n,
            source: "wallet"
        })),
        !0) : !1
    }
    updateAvailableChains(e) {
        if (!e || Object.keys(e).length === 0)
            return;
        const t = Object.entries(e).map( ([n,s]) => ({
            id: Number(n),
            rpcUrl: s
        }));
        this.availableChains = t,
        this.storeItemToStorage(tt, t),
        this.switchChain(this._activeChain.id)
    }
    updateWalletCapabilities(e) {
        this._walletCapabilities = e,
        this.storeItemToStorage(rt, e)
    }
    storeItemToStorage(e, t) {
        this.storage.setItem(e, JSON.stringify(t))
    }
    loadItemFromStorage(e) {
        const t = this.storage.getItem(e);
        return t ? JSON.parse(t) : void 0
    }
    clear() {
        this.storage.clear()
    }
}
Ee.SCWStateManager = Kr;
Object.defineProperty(ve, "__esModule", {
    value: !0
});
ve.SCWSigner = void 0;
const qr = _e
  , $r = Ee
  , oe = O
  , nt = u
  , ce = y;
class Fr {
    constructor(e) {
        this.metadata = e.metadata,
        this.communicator = e.communicator,
        this.keyManager = new qr.SCWKeyManager,
        this.stateManager = new $r.SCWStateManager({
            appChainIds: this.metadata.appChainIds,
            updateListener: e.updateListener
        }),
        this.handshake = this.handshake.bind(this),
        this.request = this.request.bind(this),
        this.createRequestMessage = this.createRequestMessage.bind(this),
        this.decryptResponseMessage = this.decryptResponseMessage.bind(this)
    }
    async handshake() {
        const e = await this.createRequestMessage({
            handshake: {
                method: "eth_requestAccounts",
                params: this.metadata
            }
        })
          , t = await this.communicator.postRequestAndWaitForResponse(e);
        if ("failure"in t.content)
            throw t.content.failure;
        const n = await (0,
        ce.importKeyFromHexString)("public", t.sender);
        await this.keyManager.setPeerPublicKey(n);
        const s = await this.decryptResponseMessage(t);
        this.updateInternalState({
            method: "eth_requestAccounts"
        }, s);
        const i = s.result;
        if ("error"in i)
            throw i.error;
        return this.stateManager.accounts
    }
    async request(e) {
        const t = this.tryLocalHandling(e);
        if (t !== void 0) {
            if (t instanceof Error)
                throw t;
            return t
        }
        await this.communicator.waitForPopupLoaded();
        const n = await this.sendEncryptedRequest(e)
          , s = await this.decryptResponseMessage(n);
        this.updateInternalState(e, s);
        const i = s.result;
        if ("error"in i)
            throw i.error;
        return i.value
    }
    async disconnect() {
        this.stateManager.clear(),
        await this.keyManager.clear()
    }
    tryLocalHandling(e) {
        var t;
        switch (e.method) {
        case "wallet_switchEthereumChain":
            {
                const n = e.params;
                if (!n || !(!((t = n[0]) === null || t === void 0) && t.chainId))
                    throw oe.standardErrors.rpc.invalidParams();
                const s = (0,
                nt.ensureIntNumber)(n[0].chainId);
                return this.stateManager.switchChain(s) ? null : void 0
            }
        case "wallet_getCapabilities":
            {
                const n = this.stateManager.walletCapabilities;
                if (!n)
                    throw oe.standardErrors.provider.unauthorized("No wallet capabilities found, please disconnect and reconnect");
                return n
            }
        default:
            return
        }
    }
    async sendEncryptedRequest(e) {
        const t = await this.keyManager.getSharedSecret();
        if (!t)
            throw oe.standardErrors.provider.unauthorized("No valid session found, try requestAccounts before other methods");
        const n = await (0,
        ce.encryptContent)({
            action: e,
            chainId: this.stateManager.activeChain.id
        }, t)
          , s = await this.createRequestMessage({
            encrypted: n
        });
        return this.communicator.postRequestAndWaitForResponse(s)
    }
    async createRequestMessage(e) {
        const t = await (0,
        ce.exportKeyToHexString)("public", await this.keyManager.getOwnPublicKey());
        return {
            id: crypto.randomUUID(),
            sender: t,
            content: e,
            timestamp: new Date
        }
    }
    async decryptResponseMessage(e) {
        const t = e.content;
        if ("failure"in t)
            throw t.failure;
        const n = await this.keyManager.getSharedSecret();
        if (!n)
            throw oe.standardErrors.provider.unauthorized("Invalid session");
        return (0,
        ce.decryptContent)(t.encrypted, n)
    }
    updateInternalState(e, t) {
        var n, s;
        const i = (n = t.data) === null || n === void 0 ? void 0 : n.chains;
        i && this.stateManager.updateAvailableChains(i);
        const a = (s = t.data) === null || s === void 0 ? void 0 : s.capabilities;
        a && this.stateManager.updateWalletCapabilities(a);
        const o = t.result;
        if (!("error"in o))
            switch (e.method) {
            case "eth_requestAccounts":
                {
                    const c = o.value;
                    this.stateManager.updateAccounts(c);
                    break
                }
            case "wallet_switchEthereumChain":
                {
                    if (o.value !== null)
                        return;
                    const c = e.params
                      , l = (0,
                    nt.ensureIntNumber)(c[0].chainId);
                    this.stateManager.switchChain(l);
                    break
                }
            }
    }
}
ve.SCWSigner = Fr;
var Se = {};
const Vr = nr;
function Wt(r) {
    return Buffer.allocUnsafe(r).fill(0)
}
function zr(r) {
    return r.toString(2).length
}
function Ut(r, e) {
    let t = r.toString(16);
    t.length % 2 !== 0 && (t = "0" + t);
    const n = t.match(/.{1,2}/g).map(s => parseInt(s, 16));
    for (; n.length < e; )
        n.unshift(0);
    return Buffer.from(n)
}
function Zr(r, e) {
    const t = r < 0n;
    let n;
    if (t) {
        const s = (1n << BigInt(e)) - 1n;
        n = (~r & s) + 1n
    } else
        n = r;
    return n &= (1n << BigInt(e)) - 1n,
    n
}
function Bt(r, e, t) {
    const n = Wt(e);
    return r = Ce(r),
    t ? r.length < e ? (r.copy(n),
    n) : r.slice(0, e) : r.length < e ? (r.copy(n, e - r.length),
    n) : r.slice(-e)
}
function Gr(r, e) {
    return Bt(r, e, !0)
}
function Ce(r) {
    if (!Buffer.isBuffer(r))
        if (Array.isArray(r))
            r = Buffer.from(r);
        else if (typeof r == "string")
            Ht(r) ? r = Buffer.from(Qr(Kt(r)), "hex") : r = Buffer.from(r);
        else if (typeof r == "number")
            r = intToBuffer(r);
        else if (r == null)
            r = Buffer.allocUnsafe(0);
        else if (typeof r == "bigint")
            r = Ut(r);
        else if (r.toArray)
            r = Buffer.from(r.toArray());
        else
            throw new Error("invalid type");
    return r
}
function Yr(r) {
    return r = Ce(r),
    "0x" + r.toString("hex")
}
function Jr(r, e) {
    return r = Ce(r),
    e || (e = 256),
    Vr("keccak" + e).update(r).digest()
}
function Qr(r) {
    return r.length % 2 ? "0" + r : r
}
function Ht(r) {
    return typeof r == "string" && r.match(/^0x[0-9A-Fa-f]*$/)
}
function Kt(r) {
    return typeof r == "string" && r.startsWith("0x") ? r.slice(2) : r
}
var qt = {
    zeros: Wt,
    setLength: Bt,
    setLengthRight: Gr,
    isHexString: Ht,
    stripHexPrefix: Kt,
    toBuffer: Ce,
    bufferToHex: Yr,
    keccak: Jr,
    bitLengthFromBigInt: zr,
    bufferBEFromBigInt: Ut,
    twosFromBigInt: Zr
};
const E = qt;
function $t(r) {
    return r.startsWith("int[") ? "int256" + r.slice(3) : r === "int" ? "int256" : r.startsWith("uint[") ? "uint256" + r.slice(4) : r === "uint" ? "uint256" : r.startsWith("fixed[") ? "fixed128x128" + r.slice(5) : r === "fixed" ? "fixed128x128" : r.startsWith("ufixed[") ? "ufixed128x128" + r.slice(6) : r === "ufixed" ? "ufixed128x128" : r
}
function G(r) {
    return parseInt(/^\D+(\d+)$/.exec(r)[1], 10)
}
function st(r) {
    var e = /^\D+(\d+)x(\d+)$/.exec(r);
    return [parseInt(e[1], 10), parseInt(e[2], 10)]
}
function Ft(r) {
    var e = r.match(/(.*)\[(.*?)\]$/);
    return e ? e[2] === "" ? "dynamic" : parseInt(e[2], 10) : null
}
function H(r) {
    var e = typeof r;
    if (e === "string" || e === "number")
        return BigInt(r);
    if (e === "bigint")
        return r;
    throw new Error("Argument is not a number")
}
function R(r, e) {
    var t, n, s, i;
    if (r === "address")
        return R("uint160", H(e));
    if (r === "bool")
        return R("uint8", e ? 1 : 0);
    if (r === "string")
        return R("bytes", new Buffer(e,"utf8"));
    if (en(r)) {
        if (typeof e.length > "u")
            throw new Error("Not an array?");
        if (t = Ft(r),
        t !== "dynamic" && t !== 0 && e.length > t)
            throw new Error("Elements exceed array size: " + t);
        s = [],
        r = r.slice(0, r.lastIndexOf("[")),
        typeof e == "string" && (e = JSON.parse(e));
        for (i in e)
            s.push(R(r, e[i]));
        if (t === "dynamic") {
            var a = R("uint256", e.length);
            s.unshift(a)
        }
        return Buffer.concat(s)
    } else {
        if (r === "bytes")
            return e = new Buffer(e),
            s = Buffer.concat([R("uint256", e.length), e]),
            e.length % 32 !== 0 && (s = Buffer.concat([s, E.zeros(32 - e.length % 32)])),
            s;
        if (r.startsWith("bytes")) {
            if (t = G(r),
            t < 1 || t > 32)
                throw new Error("Invalid bytes<N> width: " + t);
            return E.setLengthRight(e, 32)
        } else if (r.startsWith("uint")) {
            if (t = G(r),
            t % 8 || t < 8 || t > 256)
                throw new Error("Invalid uint<N> width: " + t);
            n = H(e);
            const o = E.bitLengthFromBigInt(n);
            if (o > t)
                throw new Error("Supplied uint exceeds width: " + t + " vs " + o);
            if (n < 0)
                throw new Error("Supplied uint is negative");
            return E.bufferBEFromBigInt(n, 32)
        } else if (r.startsWith("int")) {
            if (t = G(r),
            t % 8 || t < 8 || t > 256)
                throw new Error("Invalid int<N> width: " + t);
            n = H(e);
            const o = E.bitLengthFromBigInt(n);
            if (o > t)
                throw new Error("Supplied int exceeds width: " + t + " vs " + o);
            const c = E.twosFromBigInt(n, 256);
            return E.bufferBEFromBigInt(c, 32)
        } else if (r.startsWith("ufixed")) {
            if (t = st(r),
            n = H(e),
            n < 0)
                throw new Error("Supplied ufixed is negative");
            return R("uint256", n * BigInt(2) ** BigInt(t[1]))
        } else if (r.startsWith("fixed"))
            return t = st(r),
            R("int256", H(e) * BigInt(2) ** BigInt(t[1]))
    }
    throw new Error("Unsupported or invalid type: " + r)
}
function Xr(r) {
    return r === "string" || r === "bytes" || Ft(r) === "dynamic"
}
function en(r) {
    return r.lastIndexOf("]") === r.length - 1
}
function tn(r, e) {
    var t = []
      , n = []
      , s = 32 * r.length;
    for (var i in r) {
        var a = $t(r[i])
          , o = e[i]
          , c = R(a, o);
        Xr(a) ? (t.push(R("uint256", s)),
        n.push(c),
        s += c.length) : t.push(c)
    }
    return Buffer.concat(t.concat(n))
}
function Vt(r, e) {
    if (r.length !== e.length)
        throw new Error("Number of types are not matching the values");
    for (var t, n, s = [], i = 0; i < r.length; i++) {
        var a = $t(r[i])
          , o = e[i];
        if (a === "bytes")
            s.push(o);
        else if (a === "string")
            s.push(new Buffer(o,"utf8"));
        else if (a === "bool")
            s.push(new Buffer(o ? "01" : "00","hex"));
        else if (a === "address")
            s.push(E.setLength(o, 20));
        else if (a.startsWith("bytes")) {
            if (t = G(a),
            t < 1 || t > 32)
                throw new Error("Invalid bytes<N> width: " + t);
            s.push(E.setLengthRight(o, t))
        } else if (a.startsWith("uint")) {
            if (t = G(a),
            t % 8 || t < 8 || t > 256)
                throw new Error("Invalid uint<N> width: " + t);
            n = H(o);
            const c = E.bitLengthFromBigInt(n);
            if (c > t)
                throw new Error("Supplied uint exceeds width: " + t + " vs " + c);
            s.push(E.bufferBEFromBigInt(n, t / 8))
        } else if (a.startsWith("int")) {
            if (t = G(a),
            t % 8 || t < 8 || t > 256)
                throw new Error("Invalid int<N> width: " + t);
            n = H(o);
            const c = E.bitLengthFromBigInt(n);
            if (c > t)
                throw new Error("Supplied int exceeds width: " + t + " vs " + c);
            const l = E.twosFromBigInt(n, t);
            s.push(E.bufferBEFromBigInt(l, t / 8))
        } else
            throw new Error("Unsupported or invalid type: " + a)
    }
    return Buffer.concat(s)
}
function rn(r, e) {
    return E.keccak(Vt(r, e))
}
var nn = {
    rawEncode: tn,
    solidityPack: Vt,
    soliditySHA3: rn
};
const A = qt
  , X = nn
  , zt = {
    type: "object",
    properties: {
        types: {
            type: "object",
            additionalProperties: {
                type: "array",
                items: {
                    type: "object",
                    properties: {
                        name: {
                            type: "string"
                        },
                        type: {
                            type: "string"
                        }
                    },
                    required: ["name", "type"]
                }
            }
        },
        primaryType: {
            type: "string"
        },
        domain: {
            type: "object"
        },
        message: {
            type: "object"
        }
    },
    required: ["types", "primaryType", "domain", "message"]
}
  , Ue = {
    encodeData(r, e, t, n=!0) {
        const s = ["bytes32"]
          , i = [this.hashType(r, t)];
        if (n) {
            const a = (o, c, l) => {
                if (t[c] !== void 0)
                    return ["bytes32", l == null ? "0x0000000000000000000000000000000000000000000000000000000000000000" : A.keccak(this.encodeData(c, l, t, n))];
                if (l === void 0)
                    throw new Error(`missing value for field ${o} of type ${c}`);
                if (c === "bytes")
                    return ["bytes32", A.keccak(l)];
                if (c === "string")
                    return typeof l == "string" && (l = Buffer.from(l, "utf8")),
                    ["bytes32", A.keccak(l)];
                if (c.lastIndexOf("]") === c.length - 1) {
                    const h = c.slice(0, c.lastIndexOf("["))
                      , f = l.map(d => a(o, h, d));
                    return ["bytes32", A.keccak(X.rawEncode(f.map( ([d]) => d), f.map( ([,d]) => d)))]
                }
                return [c, l]
            }
            ;
            for (const o of t[r]) {
                const [c,l] = a(o.name, o.type, e[o.name]);
                s.push(c),
                i.push(l)
            }
        } else
            for (const a of t[r]) {
                let o = e[a.name];
                if (o !== void 0)
                    if (a.type === "bytes")
                        s.push("bytes32"),
                        o = A.keccak(o),
                        i.push(o);
                    else if (a.type === "string")
                        s.push("bytes32"),
                        typeof o == "string" && (o = Buffer.from(o, "utf8")),
                        o = A.keccak(o),
                        i.push(o);
                    else if (t[a.type] !== void 0)
                        s.push("bytes32"),
                        o = A.keccak(this.encodeData(a.type, o, t, n)),
                        i.push(o);
                    else {
                        if (a.type.lastIndexOf("]") === a.type.length - 1)
                            throw new Error("Arrays currently unimplemented in encodeData");
                        s.push(a.type),
                        i.push(o)
                    }
            }
        return X.rawEncode(s, i)
    },
    encodeType(r, e) {
        let t = ""
          , n = this.findTypeDependencies(r, e).filter(s => s !== r);
        n = [r].concat(n.sort());
        for (const s of n) {
            if (!e[s])
                throw new Error("No type definition specified: " + s);
            t += s + "(" + e[s].map( ({name: a, type: o}) => o + " " + a).join(",") + ")"
        }
        return t
    },
    findTypeDependencies(r, e, t=[]) {
        if (r = r.match(/^\w*/)[0],
        t.includes(r) || e[r] === void 0)
            return t;
        t.push(r);
        for (const n of e[r])
            for (const s of this.findTypeDependencies(n.type, e, t))
                !t.includes(s) && t.push(s);
        return t
    },
    hashStruct(r, e, t, n=!0) {
        return A.keccak(this.encodeData(r, e, t, n))
    },
    hashType(r, e) {
        return A.keccak(this.encodeType(r, e))
    },
    sanitizeData(r) {
        const e = {};
        for (const t in zt.properties)
            r[t] && (e[t] = r[t]);
        return e.types && (e.types = Object.assign({
            EIP712Domain: []
        }, e.types)),
        e
    },
    hash(r, e=!0) {
        const t = this.sanitizeData(r)
          , n = [Buffer.from("1901", "hex")];
        return n.push(this.hashStruct("EIP712Domain", t.domain, t.types, e)),
        t.primaryType !== "EIP712Domain" && n.push(this.hashStruct(t.primaryType, t.message, t.types, e)),
        A.keccak(Buffer.concat(n))
    }
};
var sn = {
    TYPED_MESSAGE_SCHEMA: zt,
    TypedDataUtils: Ue,
    hashForSignTypedDataLegacy: function(r) {
        return an(r.data)
    },
    hashForSignTypedData_v3: function(r) {
        return Ue.hash(r.data, !1)
    },
    hashForSignTypedData_v4: function(r) {
        return Ue.hash(r.data)
    }
};
function an(r) {
    const e = new Error("Expect argument to be non-empty array");
    if (typeof r != "object" || !r.length)
        throw e;
    const t = r.map(function(i) {
        return i.type === "bytes" ? A.toBuffer(i.value) : i.value
    })
      , n = r.map(function(i) {
        return i.type
    })
      , s = r.map(function(i) {
        if (!i.name)
            throw e;
        return i.type + " " + i.name
    });
    return X.soliditySHA3(["bytes32", "bytes32"], [X.soliditySHA3(new Array(r.length).fill("string"), s), X.soliditySHA3(n, t)])
}
var N = {};
Object.defineProperty(N, "__esModule", {
    value: !0
});
N.APP_VERSION_KEY = N.LOCAL_STORAGE_ADDRESSES_KEY = N.WALLET_USER_NAME_KEY = void 0;
N.WALLET_USER_NAME_KEY = "walletUsername";
N.LOCAL_STORAGE_ADDRESSES_KEY = "Addresses";
N.APP_VERSION_KEY = "AppVersion";
var se = {};
Object.defineProperty(se, "__esModule", {
    value: !0
});
se.RelayEventManager = void 0;
const on = u;
class cn {
    constructor() {
        this._nextRequestId = 0,
        this.callbacks = new Map
    }
    makeRequestId() {
        this._nextRequestId = (this._nextRequestId + 1) % 2147483647;
        const e = this._nextRequestId
          , t = (0,
        on.prepend0x)(e.toString(16));
        return this.callbacks.get(t) && this.callbacks.delete(t),
        e
    }
}
se.RelayEventManager = cn;
var ke = {}
  , Ie = {}
  , Me = {};
Object.defineProperty(Me, "__esModule", {
    value: !0
});
Me.WalletLinkCipher = void 0;
const de = u;
class dn {
    constructor(e) {
        this.secret = e
    }
    async encrypt(e) {
        const t = this.secret;
        if (t.length !== 64)
            throw Error("secret must be 256 bits");
        const n = crypto.getRandomValues(new Uint8Array(12))
          , s = await crypto.subtle.importKey("raw", (0,
        de.hexStringToUint8Array)(t), {
            name: "aes-gcm"
        }, !1, ["encrypt", "decrypt"])
          , i = new TextEncoder
          , a = await window.crypto.subtle.encrypt({
            name: "AES-GCM",
            iv: n
        }, s, i.encode(e))
          , o = 16
          , c = a.slice(a.byteLength - o)
          , l = a.slice(0, a.byteLength - o)
          , h = new Uint8Array(c)
          , f = new Uint8Array(l)
          , d = new Uint8Array([...n, ...h, ...f]);
        return (0,
        de.uint8ArrayToHex)(d)
    }
    async decrypt(e) {
        const t = this.secret;
        if (t.length !== 64)
            throw Error("secret must be 256 bits");
        return new Promise( (n, s) => {
            (async function() {
                const i = await crypto.subtle.importKey("raw", (0,
                de.hexStringToUint8Array)(t), {
                    name: "aes-gcm"
                }, !1, ["encrypt", "decrypt"])
                  , a = (0,
                de.hexStringToUint8Array)(e)
                  , o = a.slice(0, 12)
                  , c = a.slice(12, 28)
                  , l = a.slice(28)
                  , h = new Uint8Array([...l, ...c])
                  , f = {
                    name: "AES-GCM",
                    iv: new Uint8Array(o)
                };
                try {
                    const d = await window.crypto.subtle.decrypt(f, i, h)
                      , p = new TextDecoder;
                    n(p.decode(d))
                } catch (d) {
                    s(d)
                }
            }
            )()
        }
        )
    }
}
Me.WalletLinkCipher = dn;
var Le = {};
Object.defineProperty(Le, "__esModule", {
    value: !0
});
Le.WalletLinkHTTP = void 0;
class ln {
    constructor(e, t, n) {
        this.linkAPIUrl = e,
        this.sessionId = t;
        const s = `${t}:${n}`;
        this.auth = `Basic ${btoa(s)}`
    }
    async markUnseenEventsAsSeen(e) {
        return Promise.all(e.map(t => fetch(`${this.linkAPIUrl}/events/${t.eventId}/seen`, {
            method: "POST",
            headers: {
                Authorization: this.auth
            }
        }))).catch(t => console.error("Unabled to mark event as failed:", t))
    }
    async fetchUnseenEvents() {
        var e;
        const t = await fetch(`${this.linkAPIUrl}/events?unseen=true`, {
            headers: {
                Authorization: this.auth
            }
        });
        if (t.ok) {
            const {events: n, error: s} = await t.json();
            if (s)
                throw new Error(`Check unseen events failed: ${s}`);
            const i = (e = n == null ? void 0 : n.filter(a => a.event === "Web3Response").map(a => ({
                type: "Event",
                sessionId: this.sessionId,
                eventId: a.id,
                event: a.event,
                data: a.data
            }))) !== null && e !== void 0 ? e : [];
            return this.markUnseenEventsAsSeen(i),
            i
        }
        throw new Error(`Check unseen events failed: ${t.status}`)
    }
}
Le.WalletLinkHTTP = ln;
var Y = {};
Object.defineProperty(Y, "__esModule", {
    value: !0
});
Y.WalletLinkWebSocket = Y.ConnectionState = void 0;
var Z;
(function(r) {
    r[r.DISCONNECTED = 0] = "DISCONNECTED",
    r[r.CONNECTING = 1] = "CONNECTING",
    r[r.CONNECTED = 2] = "CONNECTED"
}
)(Z || (Y.ConnectionState = Z = {}));
class un {
    setConnectionStateListener(e) {
        this.connectionStateListener = e
    }
    setIncomingDataListener(e) {
        this.incomingDataListener = e
    }
    constructor(e, t=WebSocket) {
        this.WebSocketClass = t,
        this.webSocket = null,
        this.pendingData = [],
        this.url = e.replace(/^http/, "ws")
    }
    async connect() {
        if (this.webSocket)
            throw new Error("webSocket object is not null");
        return new Promise( (e, t) => {
            var n;
            let s;
            try {
                this.webSocket = s = new this.WebSocketClass(this.url)
            } catch (i) {
                t(i);
                return
            }
            (n = this.connectionStateListener) === null || n === void 0 || n.call(this, Z.CONNECTING),
            s.onclose = i => {
                var a;
                this.clearWebSocket(),
                t(new Error(`websocket error ${i.code}: ${i.reason}`)),
                (a = this.connectionStateListener) === null || a === void 0 || a.call(this, Z.DISCONNECTED)
            }
            ,
            s.onopen = i => {
                var a;
                e(),
                (a = this.connectionStateListener) === null || a === void 0 || a.call(this, Z.CONNECTED),
                this.pendingData.length > 0 && ([...this.pendingData].forEach(c => this.sendData(c)),
                this.pendingData = [])
            }
            ,
            s.onmessage = i => {
                var a, o;
                if (i.data === "h")
                    (a = this.incomingDataListener) === null || a === void 0 || a.call(this, {
                        type: "Heartbeat"
                    });
                else
                    try {
                        const c = JSON.parse(i.data);
                        (o = this.incomingDataListener) === null || o === void 0 || o.call(this, c)
                    } catch {}
            }
        }
        )
    }
    disconnect() {
        var e;
        const {webSocket: t} = this;
        if (t) {
            this.clearWebSocket(),
            (e = this.connectionStateListener) === null || e === void 0 || e.call(this, Z.DISCONNECTED),
            this.connectionStateListener = void 0,
            this.incomingDataListener = void 0;
            try {
                t.close()
            } catch {}
        }
    }
    sendData(e) {
        const {webSocket: t} = this;
        if (!t) {
            this.pendingData.push(e),
            this.connect();
            return
        }
        t.send(e)
    }
    clearWebSocket() {
        const {webSocket: e} = this;
        e && (this.webSocket = null,
        e.onclose = null,
        e.onerror = null,
        e.onmessage = null,
        e.onopen = null)
    }
}
Y.WalletLinkWebSocket = un;
Object.defineProperty(Ie, "__esModule", {
    value: !0
});
Ie.WalletLinkConnection = void 0;
const it = N
  , hn = Me
  , gn = Le
  , le = Y
  , F = _
  , at = 1e4
  , pn = 6e4;
class fn {
    constructor({session: e, linkAPIUrl: t, listener: n, WebSocketClass: s=WebSocket}) {
        this.destroyed = !1,
        this.lastHeartbeatResponse = 0,
        this.nextReqId = (0,
        F.IntNumber)(1),
        this._connected = !1,
        this._linked = !1,
        this.shouldFetchUnseenEventsOnConnect = !1,
        this.requestResolutions = new Map,
        this.handleSessionMetadataUpdated = a => {
            if (!a)
                return;
            new Map([["__destroyed", this.handleDestroyed], ["EthereumAddress", this.handleAccountUpdated], ["WalletUsername", this.handleWalletUsernameUpdated], ["AppVersion", this.handleAppVersionUpdated], ["ChainId", c => a.JsonRpcUrl && this.handleChainUpdated(c, a.JsonRpcUrl)]]).forEach( (c, l) => {
                const h = a[l];
                h !== void 0 && c(h)
            }
            )
        }
        ,
        this.handleDestroyed = a => {
            var o;
            a === "1" && ((o = this.listener) === null || o === void 0 || o.resetAndReload())
        }
        ,
        this.handleAccountUpdated = async a => {
            var o;
            {
                const c = await this.cipher.decrypt(a);
                (o = this.listener) === null || o === void 0 || o.accountUpdated(c)
            }
        }
        ,
        this.handleMetadataUpdated = async (a, o) => {
            var c;
            {
                const l = await this.cipher.decrypt(o);
                (c = this.listener) === null || c === void 0 || c.metadataUpdated(a, l)
            }
        }
        ,
        this.handleWalletUsernameUpdated = async a => {
            this.handleMetadataUpdated(it.WALLET_USER_NAME_KEY, a)
        }
        ,
        this.handleAppVersionUpdated = async a => {
            this.handleMetadataUpdated(it.APP_VERSION_KEY, a)
        }
        ,
        this.handleChainUpdated = async (a, o) => {
            var c;
            {
                const l = await this.cipher.decrypt(a)
                  , h = await this.cipher.decrypt(o);
                (c = this.listener) === null || c === void 0 || c.chainUpdated(l, h)
            }
        }
        ,
        this.session = e,
        this.cipher = new hn.WalletLinkCipher(e.secret),
        this.listener = n;
        const i = new le.WalletLinkWebSocket(`${t}/rpc`,s);
        i.setConnectionStateListener(async a => {
            let o = !1;
            switch (a) {
            case le.ConnectionState.DISCONNECTED:
                if (!this.destroyed) {
                    const c = async () => {
                        await new Promise(l => setTimeout(l, 5e3)),
                        this.destroyed || i.connect().catch( () => {
                            c()
                        }
                        )
                    }
                    ;
                    c()
                }
                break;
            case le.ConnectionState.CONNECTED:
                try {
                    await this.authenticate(),
                    this.sendIsLinked(),
                    this.sendGetSessionConfig(),
                    o = !0
                } catch {}
                this.updateLastHeartbeat(),
                setInterval( () => {
                    this.heartbeat()
                }
                , at),
                this.shouldFetchUnseenEventsOnConnect && this.fetchUnseenEventsAPI();
                break;
            case le.ConnectionState.CONNECTING:
                break
            }
            this.connected !== o && (this.connected = o)
        }
        ),
        i.setIncomingDataListener(a => {
            var o;
            switch (a.type) {
            case "Heartbeat":
                this.updateLastHeartbeat();
                return;
            case "IsLinkedOK":
            case "Linked":
                {
                    const c = a.type === "IsLinkedOK" ? a.linked : void 0;
                    this.linked = c || a.onlineGuests > 0;
                    break
                }
            case "GetSessionConfigOK":
            case "SessionConfigUpdated":
                {
                    this.handleSessionMetadataUpdated(a.metadata);
                    break
                }
            case "Event":
                {
                    this.handleIncomingEvent(a);
                    break
                }
            }
            a.id !== void 0 && ((o = this.requestResolutions.get(a.id)) === null || o === void 0 || o(a))
        }
        ),
        this.ws = i,
        this.http = new gn.WalletLinkHTTP(t,e.id,e.key)
    }
    connect() {
        if (this.destroyed)
            throw new Error("instance is destroyed");
        this.ws.connect()
    }
    destroy() {
        this.destroyed = !0,
        this.ws.disconnect(),
        this.listener = void 0
    }
    get isDestroyed() {
        return this.destroyed
    }
    get connected() {
        return this._connected
    }
    set connected(e) {
        var t;
        this._connected = e,
        e && ((t = this.onceConnected) === null || t === void 0 || t.call(this))
    }
    setOnceConnected(e) {
        return new Promise(t => {
            this.connected ? e().then(t) : this.onceConnected = () => {
                e().then(t),
                this.onceConnected = void 0
            }
        }
        )
    }
    get linked() {
        return this._linked
    }
    set linked(e) {
        var t, n;
        this._linked = e,
        e && ((t = this.onceLinked) === null || t === void 0 || t.call(this)),
        (n = this.listener) === null || n === void 0 || n.linkedUpdated(e)
    }
    setOnceLinked(e) {
        return new Promise(t => {
            this.linked ? e().then(t) : this.onceLinked = () => {
                e().then(t),
                this.onceLinked = void 0
            }
        }
        )
    }
    async handleIncomingEvent(e) {
        var t;
        if (!(e.type !== "Event" || e.event !== "Web3Response")) {
            const n = await this.cipher.decrypt(e.data)
              , s = JSON.parse(n);
            if (s.type !== "WEB3_RESPONSE")
                return;
            (t = this.listener) === null || t === void 0 || t.handleWeb3ResponseMessage(s)
        }
    }
    async checkUnseenEvents() {
        if (!this.connected) {
            this.shouldFetchUnseenEventsOnConnect = !0;
            return
        }
        await new Promise(e => setTimeout(e, 250));
        try {
            await this.fetchUnseenEventsAPI()
        } catch (e) {
            console.error("Unable to check for unseen events", e)
        }
    }
    async fetchUnseenEventsAPI() {
        this.shouldFetchUnseenEventsOnConnect = !1,
        (await this.http.fetchUnseenEvents()).forEach(t => this.handleIncomingEvent(t))
    }
    async setSessionMetadata(e, t) {
        const n = {
            type: "SetSessionConfig",
            id: (0,
            F.IntNumber)(this.nextReqId++),
            sessionId: this.session.id,
            metadata: {
                [e]: t
            }
        };
        return this.setOnceConnected(async () => {
            const s = await this.makeRequest(n);
            if (s.type === "Fail")
                throw new Error(s.error || "failed to set session metadata")
        }
        )
    }
    async publishEvent(e, t, n=!1) {
        const s = await this.cipher.encrypt(JSON.stringify(Object.assign(Object.assign({}, t), {
            origin: location.origin,
            relaySource: "coinbaseWalletExtension"in window && window.coinbaseWalletExtension ? "injected_sdk" : "sdk"
        })))
          , i = {
            type: "PublishEvent",
            id: (0,
            F.IntNumber)(this.nextReqId++),
            sessionId: this.session.id,
            event: e,
            data: s,
            callWebhook: n
        };
        return this.setOnceLinked(async () => {
            const a = await this.makeRequest(i);
            if (a.type === "Fail")
                throw new Error(a.error || "failed to publish event");
            return a.eventId
        }
        )
    }
    sendData(e) {
        this.ws.sendData(JSON.stringify(e))
    }
    updateLastHeartbeat() {
        this.lastHeartbeatResponse = Date.now()
    }
    heartbeat() {
        if (Date.now() - this.lastHeartbeatResponse > at * 2) {
            this.ws.disconnect();
            return
        }
        try {
            this.ws.sendData("h")
        } catch {}
    }
    async makeRequest(e, t=pn) {
        const n = e.id;
        this.sendData(e);
        let s;
        return Promise.race([new Promise( (i, a) => {
            s = window.setTimeout( () => {
                a(new Error(`request ${n} timed out`))
            }
            , t)
        }
        ), new Promise(i => {
            this.requestResolutions.set(n, a => {
                clearTimeout(s),
                i(a),
                this.requestResolutions.delete(n)
            }
            )
        }
        )])
    }
    async authenticate() {
        const e = {
            type: "HostSession",
            id: (0,
            F.IntNumber)(this.nextReqId++),
            sessionId: this.session.id,
            sessionKey: this.session.key
        }
          , t = await this.makeRequest(e);
        if (t.type === "Fail")
            throw new Error(t.error || "failed to authenticate")
    }
    sendIsLinked() {
        const e = {
            type: "IsLinked",
            id: (0,
            F.IntNumber)(this.nextReqId++),
            sessionId: this.session.id
        };
        this.sendData(e)
    }
    sendGetSessionConfig() {
        const e = {
            type: "GetSessionConfig",
            id: (0,
            F.IntNumber)(this.nextReqId++),
            sessionId: this.session.id
        };
        this.sendData(e)
    }
}
Ie.WalletLinkConnection = fn;
var Ae = {};
Object.defineProperty(Ae, "__esModule", {
    value: !0
});
Ae.WalletLinkSession = void 0;
const mn = sr
  , ot = u
  , ct = "session:id"
  , dt = "session:secret"
  , lt = "session:linked";
class ze {
    constructor(e, t, n, s) {
        this._storage = e,
        this._id = t || (0,
        ot.randomBytesHex)(16),
        this._secret = n || (0,
        ot.randomBytesHex)(32),
        this._key = new mn.sha256().update(`${this._id}, ${this._secret} WalletLink`).digest("hex"),
        this._linked = !!s
    }
    static load(e) {
        const t = e.getItem(ct)
          , n = e.getItem(lt)
          , s = e.getItem(dt);
        return t && s ? new ze(e,t,s,n === "1") : null
    }
    get id() {
        return this._id
    }
    get secret() {
        return this._secret
    }
    get key() {
        return this._key
    }
    get linked() {
        return this._linked
    }
    set linked(e) {
        this._linked = e,
        this.persistLinked()
    }
    save() {
        return this._storage.setItem(ct, this._id),
        this._storage.setItem(dt, this._secret),
        this.persistLinked(),
        this
    }
    persistLinked() {
        this._storage.setItem(lt, this._linked ? "1" : "0")
    }
}
Ae.WalletLinkSession = ze;
var S = {};
Object.defineProperty(S, "__esModule", {
    value: !0
});
S.isDarkMode = S.isMobileWeb = S.getLocation = S.createQrUrl = void 0;
function bn(r, e, t, n, s, i) {
    const a = n ? "parent-id" : "id"
      , o = new URLSearchParams({
        [a]: r,
        secret: e,
        server: t,
        v: s,
        chainId: i.toString()
    }).toString();
    return `${t}/#/link?${o}`
}
S.createQrUrl = bn;
function yn() {
    try {
        return window.frameElement !== null
    } catch {
        return !1
    }
}
function wn() {
    try {
        return yn() && window.top ? window.top.location : window.location
    } catch {
        return window.location
    }
}
S.getLocation = wn;
function vn() {
    var r;
    return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test((r = window == null ? void 0 : window.navigator) === null || r === void 0 ? void 0 : r.userAgent)
}
S.isMobileWeb = vn;
function _n() {
    var r, e;
    return (e = (r = window == null ? void 0 : window.matchMedia) === null || r === void 0 ? void 0 : r.call(window, "(prefers-color-scheme: dark)").matches) !== null && e !== void 0 ? e : !1
}
S.isDarkMode = _n;
var Re = {}
  , ie = {}
  , Ze = {};
Object.defineProperty(Ze, "__esModule", {
    value: !0
});
Ze.default = '@namespace svg "http://www.w3.org/2000/svg";.-cbwsdk-css-reset,.-cbwsdk-css-reset *{animation:none;animation-delay:0;animation-direction:normal;animation-duration:0;animation-fill-mode:none;animation-iteration-count:1;animation-name:none;animation-play-state:running;animation-timing-function:ease;backface-visibility:visible;background:0;background-attachment:scroll;background-clip:border-box;background-color:rgba(0,0,0,0);background-image:none;background-origin:padding-box;background-position:0 0;background-position-x:0;background-position-y:0;background-repeat:repeat;background-size:auto auto;border:0;border-style:none;border-width:medium;border-color:inherit;border-bottom:0;border-bottom-color:inherit;border-bottom-left-radius:0;border-bottom-right-radius:0;border-bottom-style:none;border-bottom-width:medium;border-collapse:separate;border-image:none;border-left:0;border-left-color:inherit;border-left-style:none;border-left-width:medium;border-radius:0;border-right:0;border-right-color:inherit;border-right-style:none;border-right-width:medium;border-spacing:0;border-top:0;border-top-color:inherit;border-top-left-radius:0;border-top-right-radius:0;border-top-style:none;border-top-width:medium;box-shadow:none;box-sizing:border-box;caption-side:top;clear:none;clip:auto;color:inherit;columns:auto;column-count:auto;column-fill:balance;column-gap:normal;column-rule:medium none currentColor;column-rule-color:currentColor;column-rule-style:none;column-rule-width:none;column-span:1;column-width:auto;counter-increment:none;counter-reset:none;direction:ltr;empty-cells:show;float:none;font:normal;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI","Helvetica Neue",Arial,sans-serif;font-size:medium;font-style:normal;font-variant:normal;font-weight:normal;height:auto;hyphens:none;letter-spacing:normal;line-height:normal;list-style:none;list-style-image:none;list-style-position:outside;list-style-type:disc;margin:0;margin-bottom:0;margin-left:0;margin-right:0;margin-top:0;opacity:1;orphans:0;outline:0;outline-color:invert;outline-style:none;outline-width:medium;overflow:visible;overflow-x:visible;overflow-y:visible;padding:0;padding-bottom:0;padding-left:0;padding-right:0;padding-top:0;page-break-after:auto;page-break-before:auto;page-break-inside:auto;perspective:none;perspective-origin:50% 50%;pointer-events:auto;position:static;quotes:"\\201C" "\\201D" "\\2018" "\\2019";tab-size:8;table-layout:auto;text-align:inherit;text-align-last:auto;text-decoration:none;text-decoration-color:inherit;text-decoration-line:none;text-decoration-style:solid;text-indent:0;text-shadow:none;text-transform:none;transform:none;transform-style:flat;transition:none;transition-delay:0s;transition-duration:0s;transition-property:none;transition-timing-function:ease;unicode-bidi:normal;vertical-align:baseline;visibility:visible;white-space:normal;widows:0;word-spacing:normal;z-index:auto}.-cbwsdk-css-reset strong{font-weight:bold}.-cbwsdk-css-reset *{box-sizing:border-box;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI","Helvetica Neue",Arial,sans-serif;line-height:1}.-cbwsdk-css-reset [class*=container]{margin:0;padding:0}.-cbwsdk-css-reset style{display:none}';
var En = M && M.__importDefault || function(r) {
    return r && r.__esModule ? r : {
        default: r
    }
}
;
Object.defineProperty(ie, "__esModule", {
    value: !0
});
ie.injectCssReset = void 0;
const Sn = En(Ze);
function Cn() {
    const r = document.createElement("style");
    r.type = "text/css",
    r.appendChild(document.createTextNode(Sn.default)),
    document.documentElement.appendChild(r)
}
ie.injectCssReset = Cn;
var Ge = {}
  , Ye = {};
Object.defineProperty(Ye, "__esModule", {
    value: !0
});
Ye.default = ".-cbwsdk-css-reset .-gear-container{margin-left:16px !important;margin-right:9px !important;display:flex;align-items:center;justify-content:center;width:24px;height:24px;transition:opacity .25s}.-cbwsdk-css-reset .-gear-container *{user-select:none}.-cbwsdk-css-reset .-gear-container svg{opacity:0;position:absolute}.-cbwsdk-css-reset .-gear-icon{height:12px;width:12px;z-index:10000}.-cbwsdk-css-reset .-cbwsdk-snackbar{align-items:flex-end;display:flex;flex-direction:column;position:fixed;right:0;top:0;z-index:2147483647}.-cbwsdk-css-reset .-cbwsdk-snackbar *{user-select:none}.-cbwsdk-css-reset .-cbwsdk-snackbar-instance{display:flex;flex-direction:column;margin:8px 16px 0 16px;overflow:visible;text-align:left;transform:translateX(0);transition:opacity .25s,transform .25s}.-cbwsdk-css-reset .-cbwsdk-snackbar-instance-header:hover .-gear-container svg{opacity:1}.-cbwsdk-css-reset .-cbwsdk-snackbar-instance-header{display:flex;align-items:center;background:#fff;overflow:hidden;border:1px solid #e7ebee;box-sizing:border-box;border-radius:8px;cursor:pointer}.-cbwsdk-css-reset .-cbwsdk-snackbar-instance-header-cblogo{margin:8px 8px 8px 8px}.-cbwsdk-css-reset .-cbwsdk-snackbar-instance-header *{cursor:pointer}.-cbwsdk-css-reset .-cbwsdk-snackbar-instance-header-message{color:#000;font-size:13px;line-height:1.5;user-select:none}.-cbwsdk-css-reset .-cbwsdk-snackbar-instance-menu{background:#fff;transition:opacity .25s ease-in-out,transform .25s linear,visibility 0s;visibility:hidden;border:1px solid #e7ebee;box-sizing:border-box;border-radius:8px;opacity:0;flex-direction:column;padding-left:8px;padding-right:8px}.-cbwsdk-css-reset .-cbwsdk-snackbar-instance-menu-item:last-child{margin-bottom:8px !important}.-cbwsdk-css-reset .-cbwsdk-snackbar-instance-menu-item:hover{background:#f5f7f8;border-radius:6px;transition:background .25s}.-cbwsdk-css-reset .-cbwsdk-snackbar-instance-menu-item:hover span{color:#050f19;transition:color .25s}.-cbwsdk-css-reset .-cbwsdk-snackbar-instance-menu-item:hover svg path{fill:#000;transition:fill .25s}.-cbwsdk-css-reset .-cbwsdk-snackbar-instance-menu-item{visibility:inherit;height:35px;margin-top:8px;margin-bottom:0;display:flex;flex-direction:row;align-items:center;padding:8px;cursor:pointer}.-cbwsdk-css-reset .-cbwsdk-snackbar-instance-menu-item *{visibility:inherit;cursor:pointer}.-cbwsdk-css-reset .-cbwsdk-snackbar-instance-menu-item-is-red:hover{background:rgba(223,95,103,.2);transition:background .25s}.-cbwsdk-css-reset .-cbwsdk-snackbar-instance-menu-item-is-red:hover *{cursor:pointer}.-cbwsdk-css-reset .-cbwsdk-snackbar-instance-menu-item-is-red:hover svg path{fill:#df5f67;transition:fill .25s}.-cbwsdk-css-reset .-cbwsdk-snackbar-instance-menu-item-is-red:hover span{color:#df5f67;transition:color .25s}.-cbwsdk-css-reset .-cbwsdk-snackbar-instance-menu-item-info{color:#aaa;font-size:13px;margin:0 8px 0 32px;position:absolute}.-cbwsdk-css-reset .-cbwsdk-snackbar-instance-hidden{opacity:0;text-align:left;transform:translateX(25%);transition:opacity .5s linear}.-cbwsdk-css-reset .-cbwsdk-snackbar-instance-expanded .-cbwsdk-snackbar-instance-menu{opacity:1;display:flex;transform:translateY(8px);visibility:visible}";
(function(r) {
    var e = M && M.__importDefault || function(d) {
        return d && d.__esModule ? d : {
            default: d
        }
    }
    ;
    Object.defineProperty(r, "__esModule", {
        value: !0
    }),
    r.SnackbarInstance = r.SnackbarContainer = r.Snackbar = void 0;
    const t = e(_t)
      , n = Et
      , s = ir
      , i = S
      , a = e(Ye)
      , o = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzIiIGhlaWdodD0iMzIiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PHBhdGggZD0iTTEuNDkyIDEwLjQxOWE4LjkzIDguOTMgMCAwMTguOTMtOC45M2gxMS4xNjNhOC45MyA4LjkzIDAgMDE4LjkzIDguOTN2MTEuMTYzYTguOTMgOC45MyAwIDAxLTguOTMgOC45M0gxMC40MjJhOC45MyA4LjkzIDAgMDEtOC45My04LjkzVjEwLjQxOXoiIGZpbGw9IiMxNjUyRjAiLz48cGF0aCBmaWxsLXJ1bGU9ImV2ZW5vZGQiIGNsaXAtcnVsZT0iZXZlbm9kZCIgZD0iTTEwLjQxOSAwSDIxLjU4QzI3LjMzNSAwIDMyIDQuNjY1IDMyIDEwLjQxOVYyMS41OEMzMiAyNy4zMzUgMjcuMzM1IDMyIDIxLjU4MSAzMkgxMC40MkM0LjY2NSAzMiAwIDI3LjMzNSAwIDIxLjU4MVYxMC40MkMwIDQuNjY1IDQuNjY1IDAgMTAuNDE5IDB6bTAgMS40ODhhOC45MyA4LjkzIDAgMDAtOC45MyA4LjkzdjExLjE2M2E4LjkzIDguOTMgMCAwMDguOTMgOC45M0gyMS41OGE4LjkzIDguOTMgMCAwMDguOTMtOC45M1YxMC40MmE4LjkzIDguOTMgMCAwMC04LjkzLTguOTNIMTAuNDJ6IiBmaWxsPSIjZmZmIi8+PHBhdGggZmlsbC1ydWxlPSJldmVub2RkIiBjbGlwLXJ1bGU9ImV2ZW5vZGQiIGQ9Ik0xNS45OTggMjYuMDQ5Yy01LjU0OSAwLTEwLjA0Ny00LjQ5OC0xMC4wNDctMTAuMDQ3IDAtNS41NDggNC40OTgtMTAuMDQ2IDEwLjA0Ny0xMC4wNDYgNS41NDggMCAxMC4wNDYgNC40OTggMTAuMDQ2IDEwLjA0NiAwIDUuNTQ5LTQuNDk4IDEwLjA0Ny0xMC4wNDYgMTAuMDQ3eiIgZmlsbD0iI2ZmZiIvPjxwYXRoIGQ9Ik0xMi43NjIgMTQuMjU0YzAtLjgyMi42NjctMS40ODkgMS40ODktMS40ODloMy40OTdjLjgyMiAwIDEuNDg4LjY2NiAxLjQ4OCAxLjQ4OXYzLjQ5N2MwIC44MjItLjY2NiAxLjQ4OC0xLjQ4OCAxLjQ4OGgtMy40OTdhMS40ODggMS40ODggMCAwMS0xLjQ4OS0xLjQ4OHYtMy40OTh6IiBmaWxsPSIjMTY1MkYwIi8+PC9zdmc+"
      , c = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTIiIGhlaWdodD0iMTIiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PHBhdGggZD0iTTEyIDYuNzV2LTEuNWwtMS43Mi0uNTdjLS4wOC0uMjctLjE5LS41Mi0uMzItLjc3bC44MS0xLjYyLTEuMDYtMS4wNi0xLjYyLjgxYy0uMjQtLjEzLS41LS4yNC0uNzctLjMyTDYuNzUgMGgtMS41bC0uNTcgMS43MmMtLjI3LjA4LS41My4xOS0uNzcuMzJsLTEuNjItLjgxLTEuMDYgMS4wNi44MSAxLjYyYy0uMTMuMjQtLjI0LjUtLjMyLjc3TDAgNS4yNXYxLjVsMS43Mi41N2MuMDguMjcuMTkuNTMuMzIuNzdsLS44MSAxLjYyIDEuMDYgMS4wNiAxLjYyLS44MWMuMjQuMTMuNS4yMy43Ny4zMkw1LjI1IDEyaDEuNWwuNTctMS43MmMuMjctLjA4LjUyLS4xOS43Ny0uMzJsMS42Mi44MSAxLjA2LTEuMDYtLjgxLTEuNjJjLjEzLS4yNC4yMy0uNS4zMi0uNzdMMTIgNi43NXpNNiA4LjVhMi41IDIuNSAwIDAxMC01IDIuNSAyLjUgMCAwMTAgNXoiIGZpbGw9IiMwNTBGMTkiLz48L3N2Zz4=";
    class l {
        constructor() {
            this.items = new Map,
            this.nextItemKey = 0,
            this.root = null,
            this.darkMode = (0,
            i.isDarkMode)()
        }
        attach(p) {
            this.root = document.createElement("div"),
            this.root.className = "-cbwsdk-snackbar-root",
            p.appendChild(this.root),
            this.render()
        }
        presentItem(p) {
            const m = this.nextItemKey++;
            return this.items.set(m, p),
            this.render(),
            () => {
                this.items.delete(m),
                this.render()
            }
        }
        clear() {
            this.items.clear(),
            this.render()
        }
        render() {
            this.root && (0,
            n.render)((0,
            n.h)("div", null, (0,
            n.h)(r.SnackbarContainer, {
                darkMode: this.darkMode
            }, Array.from(this.items.entries()).map( ([p,m]) => (0,
            n.h)(r.SnackbarInstance, Object.assign({}, m, {
                key: p
            }))))), this.root)
        }
    }
    r.Snackbar = l;
    const h = d => (0,
    n.h)("div", {
        class: (0,
        t.default)("-cbwsdk-snackbar-container")
    }, (0,
    n.h)("style", null, a.default), (0,
    n.h)("div", {
        class: "-cbwsdk-snackbar"
    }, d.children));
    r.SnackbarContainer = h;
    const f = ({autoExpand: d, message: p, menuItems: m}) => {
        const [B,Xt] = (0,
        s.useState)(!0)
          , [Oe,Qe] = (0,
        s.useState)(d ?? !1);
        (0,
        s.useEffect)( () => {
            const L = [window.setTimeout( () => {
                Xt(!1)
            }
            , 1), window.setTimeout( () => {
                Qe(!0)
            }
            , 1e4)];
            return () => {
                L.forEach(window.clearTimeout)
            }
        }
        );
        const er = () => {
            Qe(!Oe)
        }
        ;
        return (0,
        n.h)("div", {
            class: (0,
            t.default)("-cbwsdk-snackbar-instance", B && "-cbwsdk-snackbar-instance-hidden", Oe && "-cbwsdk-snackbar-instance-expanded")
        }, (0,
        n.h)("div", {
            class: "-cbwsdk-snackbar-instance-header",
            onClick: er
        }, (0,
        n.h)("img", {
            src: o,
            class: "-cbwsdk-snackbar-instance-header-cblogo"
        }), " ", (0,
        n.h)("div", {
            class: "-cbwsdk-snackbar-instance-header-message"
        }, p), (0,
        n.h)("div", {
            class: "-gear-container"
        }, !Oe && (0,
        n.h)("svg", {
            width: "24",
            height: "24",
            viewBox: "0 0 24 24",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg"
        }, (0,
        n.h)("circle", {
            cx: "12",
            cy: "12",
            r: "12",
            fill: "#F5F7F8"
        })), (0,
        n.h)("img", {
            src: c,
            class: "-gear-icon",
            title: "Expand"
        }))), m && m.length > 0 && (0,
        n.h)("div", {
            class: "-cbwsdk-snackbar-instance-menu"
        }, m.map( (L, tr) => (0,
        n.h)("div", {
            class: (0,
            t.default)("-cbwsdk-snackbar-instance-menu-item", L.isRed && "-cbwsdk-snackbar-instance-menu-item-is-red"),
            onClick: L.onClick,
            key: tr
        }, (0,
        n.h)("svg", {
            width: L.svgWidth,
            height: L.svgHeight,
            viewBox: "0 0 10 11",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg"
        }, (0,
        n.h)("path", {
            "fill-rule": L.defaultFillRule,
            "clip-rule": L.defaultClipRule,
            d: L.path,
            fill: "#AAAAAA"
        })), (0,
        n.h)("span", {
            class: (0,
            t.default)("-cbwsdk-snackbar-instance-menu-item-info", L.isRed && "-cbwsdk-snackbar-instance-menu-item-info-is-red")
        }, L.info)))))
    }
    ;
    r.SnackbarInstance = f
}
)(Ge);
Object.defineProperty(Re, "__esModule", {
    value: !0
});
Re.WalletLinkRelayUI = void 0;
const kn = ie
  , In = Ge;
class Mn {
    constructor() {
        this.attached = !1,
        this.snackbar = new In.Snackbar
    }
    attach() {
        if (this.attached)
            throw new Error("Coinbase Wallet SDK UI is already attached");
        const e = document.documentElement
          , t = document.createElement("div");
        t.className = "-cbwsdk-css-reset",
        e.appendChild(t),
        this.snackbar.attach(t),
        this.attached = !0,
        (0,
        kn.injectCssReset)()
    }
    showConnecting(e) {
        let t;
        return e.isUnlinkedErrorState ? t = {
            autoExpand: !0,
            message: "Connection lost",
            menuItems: [{
                isRed: !1,
                info: "Reset connection",
                svgWidth: "10",
                svgHeight: "11",
                path: "M5.00008 0.96875C6.73133 0.96875 8.23758 1.94375 9.00008 3.375L10.0001 2.375V5.5H9.53133H7.96883H6.87508L7.80633 4.56875C7.41258 3.3875 6.31258 2.53125 5.00008 2.53125C3.76258 2.53125 2.70633 3.2875 2.25633 4.36875L0.812576 3.76875C1.50008 2.125 3.11258 0.96875 5.00008 0.96875ZM2.19375 6.43125C2.5875 7.6125 3.6875 8.46875 5 8.46875C6.2375 8.46875 7.29375 7.7125 7.74375 6.63125L9.1875 7.23125C8.5 8.875 6.8875 10.0312 5 10.0312C3.26875 10.0312 1.7625 9.05625 1 7.625L0 8.625V5.5H0.46875H2.03125H3.125L2.19375 6.43125Z",
                defaultFillRule: "evenodd",
                defaultClipRule: "evenodd",
                onClick: e.onResetConnection
            }]
        } : t = {
            message: "Confirm on phone",
            menuItems: [{
                isRed: !0,
                info: "Cancel transaction",
                svgWidth: "11",
                svgHeight: "11",
                path: "M10.3711 1.52346L9.21775 0.370117L5.37109 4.21022L1.52444 0.370117L0.371094 1.52346L4.2112 5.37012L0.371094 9.21677L1.52444 10.3701L5.37109 6.53001L9.21775 10.3701L10.3711 9.21677L6.53099 5.37012L10.3711 1.52346Z",
                defaultFillRule: "inherit",
                defaultClipRule: "inherit",
                onClick: e.onCancel
            }, {
                isRed: !1,
                info: "Reset connection",
                svgWidth: "10",
                svgHeight: "11",
                path: "M5.00008 0.96875C6.73133 0.96875 8.23758 1.94375 9.00008 3.375L10.0001 2.375V5.5H9.53133H7.96883H6.87508L7.80633 4.56875C7.41258 3.3875 6.31258 2.53125 5.00008 2.53125C3.76258 2.53125 2.70633 3.2875 2.25633 4.36875L0.812576 3.76875C1.50008 2.125 3.11258 0.96875 5.00008 0.96875ZM2.19375 6.43125C2.5875 7.6125 3.6875 8.46875 5 8.46875C6.2375 8.46875 7.29375 7.7125 7.74375 6.63125L9.1875 7.23125C8.5 8.875 6.8875 10.0312 5 10.0312C3.26875 10.0312 1.7625 9.05625 1 7.625L0 8.625V5.5H0.46875H2.03125H3.125L2.19375 6.43125Z",
                defaultFillRule: "evenodd",
                defaultClipRule: "evenodd",
                onClick: e.onResetConnection
            }]
        },
        this.snackbar.presentItem(t)
    }
}
Re.WalletLinkRelayUI = Mn;
var xe = {}
  , Pe = {}
  , Je = {};
Object.defineProperty(Je, "__esModule", {
    value: !0
});
Je.default = ".-cbwsdk-css-reset .-cbwsdk-redirect-dialog-backdrop{position:fixed;top:0;left:0;right:0;bottom:0;transition:opacity .25s;background-color:rgba(10,11,13,.5)}.-cbwsdk-css-reset .-cbwsdk-redirect-dialog-backdrop-hidden{opacity:0}.-cbwsdk-css-reset .-cbwsdk-redirect-dialog-box{display:block;position:fixed;top:50%;left:50%;transform:translate(-50%, -50%);padding:20px;border-radius:8px;background-color:#fff;color:#0a0b0d}.-cbwsdk-css-reset .-cbwsdk-redirect-dialog-box p{display:block;font-weight:400;font-size:14px;line-height:20px;padding-bottom:12px;color:#5b636e}.-cbwsdk-css-reset .-cbwsdk-redirect-dialog-box button{appearance:none;border:none;background:none;color:#0052ff;padding:0;text-decoration:none;display:block;font-weight:600;font-size:16px;line-height:24px}.-cbwsdk-css-reset .-cbwsdk-redirect-dialog-box.dark{background-color:#0a0b0d;color:#fff}.-cbwsdk-css-reset .-cbwsdk-redirect-dialog-box.dark button{color:#0052ff}.-cbwsdk-css-reset .-cbwsdk-redirect-dialog-box.light{background-color:#fff;color:#0a0b0d}.-cbwsdk-css-reset .-cbwsdk-redirect-dialog-box.light button{color:#0052ff}";
var Zt = M && M.__importDefault || function(r) {
    return r && r.__esModule ? r : {
        default: r
    }
}
;
Object.defineProperty(Pe, "__esModule", {
    value: !0
});
Pe.RedirectDialog = void 0;
const Ln = Zt(_t)
  , x = Et
  , An = ie
  , Rn = Ge
  , xn = S
  , Pn = Zt(Je);
class Nn {
    constructor() {
        this.root = null,
        this.darkMode = (0,
        xn.isDarkMode)()
    }
    attach() {
        const e = document.documentElement;
        this.root = document.createElement("div"),
        this.root.className = "-cbwsdk-css-reset",
        e.appendChild(this.root),
        (0,
        An.injectCssReset)()
    }
    present(e) {
        this.render(e)
    }
    clear() {
        this.render(null)
    }
    render(e) {
        this.root && ((0,
        x.render)(null, this.root),
        e && (0,
        x.render)((0,
        x.h)(Tn, Object.assign({}, e, {
            onDismiss: () => {
                this.clear()
            }
            ,
            darkMode: this.darkMode
        })), this.root))
    }
}
Pe.RedirectDialog = Nn;
const Tn = ({title: r, buttonText: e, darkMode: t, onButtonClick: n, onDismiss: s}) => {
    const i = t ? "dark" : "light";
    return (0,
    x.h)(Rn.SnackbarContainer, {
        darkMode: t
    }, (0,
    x.h)("div", {
        class: "-cbwsdk-redirect-dialog"
    }, (0,
    x.h)("style", null, Pn.default), (0,
    x.h)("div", {
        class: "-cbwsdk-redirect-dialog-backdrop",
        onClick: s
    }), (0,
    x.h)("div", {
        class: (0,
        Ln.default)("-cbwsdk-redirect-dialog-box", i)
    }, (0,
    x.h)("p", null, r), (0,
    x.h)("button", {
        onClick: n
    }, e))))
}
;
var T = {};
Object.defineProperty(T, "__esModule", {
    value: !0
});
T.CBW_MOBILE_DEEPLINK_URL = T.WALLETLINK_URL = T.CB_KEYS_URL = void 0;
T.CB_KEYS_URL = "https://keys.coinbase.com/connect";
T.WALLETLINK_URL = "https://www.walletlink.org";
T.CBW_MOBILE_DEEPLINK_URL = "https://go.cb-w.com/walletlink";
Object.defineProperty(xe, "__esModule", {
    value: !0
});
xe.WLMobileRelayUI = void 0;
const On = Pe
  , jn = S
  , Dn = T;
class Wn {
    constructor() {
        this.attached = !1,
        this.redirectDialog = new On.RedirectDialog
    }
    attach() {
        if (this.attached)
            throw new Error("Coinbase Wallet SDK UI is already attached");
        this.redirectDialog.attach(),
        this.attached = !0
    }
    redirectToCoinbaseWallet(e) {
        const t = new URL(Dn.CBW_MOBILE_DEEPLINK_URL);
        t.searchParams.append("redirect_url", (0,
        jn.getLocation)().href),
        e && t.searchParams.append("wl_url", e);
        const n = document.createElement("a");
        n.target = "cbw-opener",
        n.href = t.href,
        n.rel = "noreferrer noopener",
        n.click()
    }
    openCoinbaseWalletDeeplink(e) {
        this.redirectDialog.present({
            title: "Redirecting to Coinbase Wallet...",
            buttonText: "Open",
            onButtonClick: () => {
                this.redirectToCoinbaseWallet(e)
            }
        }),
        setTimeout( () => {
            this.redirectToCoinbaseWallet(e)
        }
        , 99)
    }
    showConnecting(e) {
        return () => {
            this.redirectDialog.clear()
        }
    }
}
xe.WLMobileRelayUI = Wn;
Object.defineProperty(ke, "__esModule", {
    value: !0
});
ke.WalletLinkRelay = void 0;
const Un = Ie
  , Bn = N
  , Hn = se
  , Be = Ae
  , V = Q
  , Kn = S
  , qn = Re
  , ut = xe
  , $n = O
  , b = u
  , Fn = j;
class W {
    constructor(e) {
        this.accountsCallback = null,
        this.chainCallbackParams = {
            chainId: "",
            jsonRpcUrl: ""
        },
        this.chainCallback = null,
        this.dappDefaultChain = 1,
        this.isMobileWeb = (0,
        Kn.isMobileWeb)(),
        this.appName = "",
        this.appLogoUrl = null,
        this.linkedUpdated = i => {
            this.isLinked = i;
            const a = this.storage.getItem(Bn.LOCAL_STORAGE_ADDRESSES_KEY);
            if (i && (this._session.linked = i),
            this.isUnlinkedErrorState = !1,
            a) {
                const o = a.split(" ")
                  , c = this.storage.getItem("IsStandaloneSigning") === "true";
                o[0] !== "" && !i && this._session.linked && !c && (this.isUnlinkedErrorState = !0)
            }
        }
        ,
        this.metadataUpdated = (i, a) => {
            this.storage.setItem(i, a)
        }
        ,
        this.chainUpdated = (i, a) => {
            this.chainCallbackParams.chainId === i && this.chainCallbackParams.jsonRpcUrl === a || (this.chainCallbackParams = {
                chainId: i,
                jsonRpcUrl: a
            },
            this.chainCallback && this.chainCallback(i, a))
        }
        ,
        this.accountUpdated = i => {
            this.accountsCallback && this.accountsCallback([i]),
            W.accountRequestCallbackIds.size > 0 && (Array.from(W.accountRequestCallbackIds.values()).forEach(a => {
                const o = {
                    type: "WEB3_RESPONSE",
                    id: a,
                    response: {
                        method: "requestEthereumAccounts",
                        result: [i]
                    }
                };
                this.invokeCallback(Object.assign(Object.assign({}, o), {
                    id: a
                }))
            }
            ),
            W.accountRequestCallbackIds.clear())
        }
        ,
        this.resetAndReload = this.resetAndReload.bind(this),
        this.linkAPIUrl = e.linkAPIUrl,
        this.storage = e.storage;
        const {session: t, ui: n, connection: s} = this.subscribe();
        this._session = t,
        this.connection = s,
        this.relayEventManager = new Hn.RelayEventManager,
        this.ui = n
    }
    subscribe() {
        const e = Be.WalletLinkSession.load(this.storage) || new Be.WalletLinkSession(this.storage).save()
          , {linkAPIUrl: t} = this
          , n = new Un.WalletLinkConnection({
            session: e,
            linkAPIUrl: t,
            listener: this
        })
          , s = this.isMobileWeb ? new ut.WLMobileRelayUI : new qn.WalletLinkRelayUI;
        return n.connect(),
        {
            session: e,
            ui: s,
            connection: n
        }
    }
    attachUI() {
        this.ui.attach()
    }
    resetAndReload() {
        Promise.race([this.connection.setSessionMetadata("__destroyed", "1"), new Promise(e => setTimeout( () => e(null), 1e3))]).then( () => {
            this.connection.destroy();
            const e = Be.WalletLinkSession.load(this.storage);
            (e == null ? void 0 : e.id) === this._session.id && Fn.ScopedLocalStorage.clearAll(),
            document.location.reload()
        }
        ).catch(e => {}
        )
    }
    setAppInfo(e, t) {
        this.appName = e,
        this.appLogoUrl = t
    }
    getStorageItem(e) {
        return this.storage.getItem(e)
    }
    setStorageItem(e, t) {
        this.storage.setItem(e, t)
    }
    signEthereumMessage(e, t, n, s) {
        return this.sendRequest({
            method: "signEthereumMessage",
            params: {
                message: (0,
                b.hexStringFromBuffer)(e, !0),
                address: t,
                addPrefix: n,
                typedDataJson: s || null
            }
        })
    }
    ethereumAddressFromSignedMessage(e, t, n) {
        return this.sendRequest({
            method: "ethereumAddressFromSignedMessage",
            params: {
                message: (0,
                b.hexStringFromBuffer)(e, !0),
                signature: (0,
                b.hexStringFromBuffer)(t, !0),
                addPrefix: n
            }
        })
    }
    signEthereumTransaction(e) {
        return this.sendRequest({
            method: "signEthereumTransaction",
            params: {
                fromAddress: e.fromAddress,
                toAddress: e.toAddress,
                weiValue: (0,
                b.bigIntStringFromBigInt)(e.weiValue),
                data: (0,
                b.hexStringFromBuffer)(e.data, !0),
                nonce: e.nonce,
                gasPriceInWei: e.gasPriceInWei ? (0,
                b.bigIntStringFromBigInt)(e.gasPriceInWei) : null,
                maxFeePerGas: e.gasPriceInWei ? (0,
                b.bigIntStringFromBigInt)(e.gasPriceInWei) : null,
                maxPriorityFeePerGas: e.gasPriceInWei ? (0,
                b.bigIntStringFromBigInt)(e.gasPriceInWei) : null,
                gasLimit: e.gasLimit ? (0,
                b.bigIntStringFromBigInt)(e.gasLimit) : null,
                chainId: e.chainId,
                shouldSubmit: !1
            }
        })
    }
    signAndSubmitEthereumTransaction(e) {
        return this.sendRequest({
            method: "signEthereumTransaction",
            params: {
                fromAddress: e.fromAddress,
                toAddress: e.toAddress,
                weiValue: (0,
                b.bigIntStringFromBigInt)(e.weiValue),
                data: (0,
                b.hexStringFromBuffer)(e.data, !0),
                nonce: e.nonce,
                gasPriceInWei: e.gasPriceInWei ? (0,
                b.bigIntStringFromBigInt)(e.gasPriceInWei) : null,
                maxFeePerGas: e.maxFeePerGas ? (0,
                b.bigIntStringFromBigInt)(e.maxFeePerGas) : null,
                maxPriorityFeePerGas: e.maxPriorityFeePerGas ? (0,
                b.bigIntStringFromBigInt)(e.maxPriorityFeePerGas) : null,
                gasLimit: e.gasLimit ? (0,
                b.bigIntStringFromBigInt)(e.gasLimit) : null,
                chainId: e.chainId,
                shouldSubmit: !0
            }
        })
    }
    submitEthereumTransaction(e, t) {
        return this.sendRequest({
            method: "submitEthereumTransaction",
            params: {
                signedTransaction: (0,
                b.hexStringFromBuffer)(e, !0),
                chainId: t
            }
        })
    }
    scanQRCode(e) {
        return this.sendRequest({
            method: "scanQRCode",
            params: {
                regExp: e
            }
        })
    }
    getWalletLinkSession() {
        return this._session
    }
    genericRequest(e, t) {
        return this.sendRequest({
            method: "generic",
            params: {
                action: t,
                data: e
            }
        })
    }
    sendGenericMessage(e) {
        return this.sendRequest(e)
    }
    sendRequest(e) {
        let t = null;
        const n = (0,
        b.randomBytesHex)(8)
          , s = i => {
            this.publishWeb3RequestCanceledEvent(n),
            this.handleErrorResponse(n, e.method, i),
            t == null || t()
        }
        ;
        return new Promise( (i, a) => {
            t = this.ui.showConnecting({
                isUnlinkedErrorState: this.isUnlinkedErrorState,
                onCancel: s,
                onResetConnection: this.resetAndReload
            }),
            this.relayEventManager.callbacks.set(n, o => {
                if (t == null || t(),
                (0,
                V.isErrorResponse)(o))
                    return a(new Error(o.errorMessage));
                i(o)
            }
            ),
            this.publishWeb3RequestEvent(n, e)
        }
        )
    }
    setAccountsCallback(e) {
        this.accountsCallback = e
    }
    setChainCallback(e) {
        this.chainCallback = e
    }
    setDappDefaultChainCallback(e) {
        this.dappDefaultChain = e
    }
    publishWeb3RequestEvent(e, t) {
        const n = {
            type: "WEB3_REQUEST",
            id: e,
            request: t
        };
        this.publishEvent("Web3Request", n, !0).then(s => {}
        ).catch(s => {
            this.handleWeb3ResponseMessage({
                type: "WEB3_RESPONSE",
                id: n.id,
                response: {
                    method: t.method,
                    errorMessage: s.message
                }
            })
        }
        ),
        this.isMobileWeb && this.openCoinbaseWalletDeeplink(t.method)
    }
    openCoinbaseWalletDeeplink(e) {
        if (this.ui instanceof ut.WLMobileRelayUI)
            switch (e) {
            case "requestEthereumAccounts":
            case "switchEthereumChain":
                return;
            default:
                window.addEventListener("blur", () => {
                    window.addEventListener("focus", () => {
                        this.connection.checkUnseenEvents()
                    }
                    , {
                        once: !0
                    })
                }
                , {
                    once: !0
                }),
                this.ui.openCoinbaseWalletDeeplink();
                break
            }
    }
    publishWeb3RequestCanceledEvent(e) {
        const t = {
            type: "WEB3_REQUEST_CANCELED",
            id: e
        };
        this.publishEvent("Web3RequestCanceled", t, !1).then()
    }
    publishEvent(e, t, n) {
        return this.connection.publishEvent(e, t, n)
    }
    handleWeb3ResponseMessage(e) {
        const {response: t} = e;
        if (t.method === "requestEthereumAccounts") {
            W.accountRequestCallbackIds.forEach(n => this.invokeCallback(Object.assign(Object.assign({}, e), {
                id: n
            }))),
            W.accountRequestCallbackIds.clear();
            return
        }
        this.invokeCallback(e)
    }
    handleErrorResponse(e, t, n) {
        var s;
        const i = (s = n == null ? void 0 : n.message) !== null && s !== void 0 ? s : "Unspecified error message.";
        this.handleWeb3ResponseMessage({
            type: "WEB3_RESPONSE",
            id: e,
            response: {
                method: t,
                errorMessage: i
            }
        })
    }
    invokeCallback(e) {
        const t = this.relayEventManager.callbacks.get(e.id);
        t && (t(e.response),
        this.relayEventManager.callbacks.delete(e.id))
    }
    requestEthereumAccounts() {
        const e = {
            method: "requestEthereumAccounts",
            params: {
                appName: this.appName,
                appLogoUrl: this.appLogoUrl || null
            }
        }
          , t = (0,
        b.randomBytesHex)(8);
        return new Promise( (n, s) => {
            this.relayEventManager.callbacks.set(t, i => {
                if ((0,
                V.isErrorResponse)(i))
                    return s(new Error(i.errorMessage));
                n(i)
            }
            ),
            W.accountRequestCallbackIds.add(t),
            this.publishWeb3RequestEvent(t, e)
        }
        )
    }
    watchAsset(e, t, n, s, i, a) {
        const o = {
            method: "watchAsset",
            params: {
                type: e,
                options: {
                    address: t,
                    symbol: n,
                    decimals: s,
                    image: i
                },
                chainId: a
            }
        };
        let c = null;
        const l = (0,
        b.randomBytesHex)(8)
          , h = f => {
            this.publishWeb3RequestCanceledEvent(l),
            this.handleErrorResponse(l, o.method, f),
            c == null || c()
        }
        ;
        return c = this.ui.showConnecting({
            isUnlinkedErrorState: this.isUnlinkedErrorState,
            onCancel: h,
            onResetConnection: this.resetAndReload
        }),
        new Promise( (f, d) => {
            this.relayEventManager.callbacks.set(l, p => {
                if (c == null || c(),
                (0,
                V.isErrorResponse)(p))
                    return d(new Error(p.errorMessage));
                f(p)
            }
            ),
            this.publishWeb3RequestEvent(l, o)
        }
        )
    }
    addEthereumChain(e, t, n, s, i, a) {
        const o = {
            method: "addEthereumChain",
            params: {
                chainId: e,
                rpcUrls: t,
                blockExplorerUrls: s,
                chainName: i,
                iconUrls: n,
                nativeCurrency: a
            }
        };
        let c = null;
        const l = (0,
        b.randomBytesHex)(8)
          , h = f => {
            this.publishWeb3RequestCanceledEvent(l),
            this.handleErrorResponse(l, o.method, f),
            c == null || c()
        }
        ;
        return c = this.ui.showConnecting({
            isUnlinkedErrorState: this.isUnlinkedErrorState,
            onCancel: h,
            onResetConnection: this.resetAndReload
        }),
        new Promise( (f, d) => {
            this.relayEventManager.callbacks.set(l, p => {
                if (c == null || c(),
                (0,
                V.isErrorResponse)(p))
                    return d(new Error(p.errorMessage));
                f(p)
            }
            ),
            this.publishWeb3RequestEvent(l, o)
        }
        )
    }
    switchEthereumChain(e, t) {
        const n = {
            method: "switchEthereumChain",
            params: Object.assign({
                chainId: e
            }, {
                address: t
            })
        }
          , s = (0,
        b.randomBytesHex)(8);
        return new Promise( (i, a) => {
            this.relayEventManager.callbacks.set(s, o => {
                if ((0,
                V.isErrorResponse)(o) && o.errorCode)
                    return a($n.standardErrors.provider.custom({
                        code: o.errorCode,
                        message: "Unrecognized chain ID. Try adding the chain using addEthereumChain first."
                    }));
                if ((0,
                V.isErrorResponse)(o))
                    return a(new Error(o.errorMessage));
                i(o)
            }
            ),
            this.publishWeb3RequestEvent(s, n)
        }
        )
    }
}
ke.WalletLinkRelay = W;
W.accountRequestCallbackIds = new Set;
var Vn = M && M.__importDefault || function(r) {
    return r && r.__esModule ? r : {
        default: r
    }
}
;
Object.defineProperty(Se, "__esModule", {
    value: !0
});
Se.WalletLinkSigner = void 0;
const He = Vn(sn)
  , ht = N
  , zn = se
  , D = Q
  , Zn = ke
  , gt = T
  , w = O
  , g = u
  , Gn = j
  , Ke = "DefaultChainId"
  , pt = "DefaultJsonRpcUrl";
class Yn {
    constructor(e) {
        var t, n;
        this._relay = null,
        this._addresses = [],
        this.hasMadeFirstChainChangedEmission = !1;
        const {appName: s, appLogoUrl: i} = e.metadata;
        this._appName = s,
        this._appLogoUrl = i,
        this._storage = new Gn.ScopedLocalStorage("walletlink",gt.WALLETLINK_URL),
        this.updateListener = e.updateListener,
        this._relayEventManager = new zn.RelayEventManager,
        this._jsonRpcUrlFromOpts = "";
        const a = this._storage.getItem(ht.LOCAL_STORAGE_ADDRESSES_KEY);
        if (a) {
            const c = a.split(" ");
            c[0] !== "" && (this._addresses = c.map(l => (0,
            g.ensureAddressString)(l)),
            (t = this.updateListener) === null || t === void 0 || t.onAccountsUpdate({
                accounts: this._addresses,
                source: "storage"
            }))
        }
        this._storage.getItem(Ke) && ((n = this.updateListener) === null || n === void 0 || n.onChainUpdate({
            chain: {
                id: this.getChainId(),
                rpcUrl: this.jsonRpcUrl
            },
            source: "storage"
        }),
        this.hasMadeFirstChainChangedEmission = !0),
        this.initializeRelay()
    }
    getSession() {
        const e = this.initializeRelay()
          , {id: t, secret: n} = e.getWalletLinkSession();
        return {
            id: t,
            secret: n
        }
    }
    async handshake() {
        return await this.request({
            method: "eth_requestAccounts"
        })
    }
    get selectedAddress() {
        return this._addresses[0] || void 0
    }
    get jsonRpcUrl() {
        var e;
        return (e = this._storage.getItem(pt)) !== null && e !== void 0 ? e : this._jsonRpcUrlFromOpts
    }
    set jsonRpcUrl(e) {
        this._storage.setItem(pt, e)
    }
    updateProviderInfo(e, t) {
        var n;
        this.jsonRpcUrl = e;
        const s = this.getChainId();
        this._storage.setItem(Ke, t.toString(10)),
        ((0,
        g.ensureIntNumber)(t) !== s || !this.hasMadeFirstChainChangedEmission) && ((n = this.updateListener) === null || n === void 0 || n.onChainUpdate({
            chain: {
                id: t,
                rpcUrl: e
            },
            source: "wallet"
        }),
        this.hasMadeFirstChainChangedEmission = !0)
    }
    async watchAsset(e, t, n, s, i, a) {
        const c = await this.initializeRelay().watchAsset(e, t, n, s, i, a == null ? void 0 : a.toString());
        return (0,
        D.isErrorResponse)(c) ? !1 : !!c.result
    }
    async addEthereumChain(e, t, n, s, i, a) {
        var o, c;
        if ((0,
        g.ensureIntNumber)(e) === this.getChainId())
            return !1;
        const l = this.initializeRelay();
        this._isAuthorized() || await l.requestEthereumAccounts();
        const h = await l.addEthereumChain(e.toString(), t, i, n, s, a);
        return (0,
        D.isErrorResponse)(h) ? !1 : (((o = h.result) === null || o === void 0 ? void 0 : o.isApproved) === !0 && this.updateProviderInfo(t[0], e),
        ((c = h.result) === null || c === void 0 ? void 0 : c.isApproved) === !0)
    }
    async switchEthereumChain(e) {
        const n = await this.initializeRelay().switchEthereumChain(e.toString(10), this.selectedAddress || void 0);
        if ((0,
        D.isErrorResponse)(n)) {
            if (!n.errorCode)
                return;
            throw n.errorCode === w.standardErrorCodes.provider.unsupportedChain ? w.standardErrors.provider.unsupportedChain() : w.standardErrors.provider.custom({
                message: n.errorMessage,
                code: n.errorCode
            })
        }
        const s = n.result;
        s.isApproved && s.rpcUrl.length > 0 && this.updateProviderInfo(s.rpcUrl, e)
    }
    async disconnect() {
        this._relay && this._relay.resetAndReload(),
        this._storage.clear()
    }
    async request(e) {
        try {
            return this._request(e).catch(t => {
                throw t
            }
            )
        } catch (t) {
            return Promise.reject(t)
        }
    }
    async _request(e) {
        if (!e || typeof e != "object" || Array.isArray(e))
            throw w.standardErrors.rpc.invalidRequest({
                message: "Expected a single, non-array, object argument.",
                data: e
            });
        const {method: t, params: n} = e;
        if (typeof t != "string" || t.length === 0)
            throw w.standardErrors.rpc.invalidRequest({
                message: "'args.method' must be a non-empty string.",
                data: e
            });
        if (n !== void 0 && !Array.isArray(n) && (typeof n != "object" || n === null))
            throw w.standardErrors.rpc.invalidRequest({
                message: "'args.params' must be an object or array if provided.",
                data: e
            });
        const s = n === void 0 ? [] : n
          , i = this._relayEventManager.makeRequestId();
        return (await this._sendRequestAsync({
            method: t,
            params: s,
            jsonrpc: "2.0",
            id: i
        })).result
    }
    _setAddresses(e, t) {
        var n;
        if (!Array.isArray(e))
            throw new Error("addresses is not an array");
        const s = e.map(i => (0,
        g.ensureAddressString)(i));
        JSON.stringify(s) !== JSON.stringify(this._addresses) && (this._addresses = s,
        (n = this.updateListener) === null || n === void 0 || n.onAccountsUpdate({
            accounts: s,
            source: "wallet"
        }),
        this._storage.setItem(ht.LOCAL_STORAGE_ADDRESSES_KEY, s.join(" ")))
    }
    _sendRequestAsync(e) {
        return new Promise( (t, n) => {
            try {
                const s = this._handleSynchronousMethods(e);
                if (s !== void 0)
                    return t({
                        jsonrpc: "2.0",
                        id: e.id,
                        result: s
                    })
            } catch (s) {
                return n(s)
            }
            this._handleAsynchronousMethods(e).then(s => s && t(Object.assign(Object.assign({}, s), {
                id: e.id
            }))).catch(s => n(s))
        }
        )
    }
    _handleSynchronousMethods(e) {
        const {method: t} = e;
        switch (t) {
        case "eth_accounts":
            return this._eth_accounts();
        case "eth_coinbase":
            return this._eth_coinbase();
        case "net_version":
            return this._net_version();
        case "eth_chainId":
            return this._eth_chainId();
        default:
            return
        }
    }
    async _handleAsynchronousMethods(e) {
        const {method: t} = e
          , n = e.params || [];
        switch (t) {
        case "eth_requestAccounts":
            return this._eth_requestAccounts();
        case "eth_sign":
            return this._eth_sign(n);
        case "eth_ecRecover":
            return this._eth_ecRecover(n);
        case "personal_sign":
            return this._personal_sign(n);
        case "personal_ecRecover":
            return this._personal_ecRecover(n);
        case "eth_signTransaction":
            return this._eth_signTransaction(n);
        case "eth_sendRawTransaction":
            return this._eth_sendRawTransaction(n);
        case "eth_sendTransaction":
            return this._eth_sendTransaction(n);
        case "eth_signTypedData_v1":
            return this._eth_signTypedData_v1(n);
        case "eth_signTypedData_v2":
            return this._throwUnsupportedMethodError();
        case "eth_signTypedData_v3":
            return this._eth_signTypedData_v3(n);
        case "eth_signTypedData_v4":
        case "eth_signTypedData":
            return this._eth_signTypedData_v4(n);
        case "wallet_addEthereumChain":
            return this._wallet_addEthereumChain(n);
        case "wallet_switchEthereumChain":
            return this._wallet_switchEthereumChain(n);
        case "wallet_watchAsset":
            return this._wallet_watchAsset(n);
        default:
            return this._throwUnsupportedMethodError()
        }
    }
    _isKnownAddress(e) {
        try {
            const t = (0,
            g.ensureAddressString)(e);
            return this._addresses.map(s => (0,
            g.ensureAddressString)(s)).includes(t)
        } catch {}
        return !1
    }
    _ensureKnownAddress(e) {
        if (!this._isKnownAddress(e))
            throw new Error("Unknown Ethereum address")
    }
    _prepareTransactionParams(e) {
        const t = e.from ? (0,
        g.ensureAddressString)(e.from) : this.selectedAddress;
        if (!t)
            throw new Error("Ethereum address is unavailable");
        this._ensureKnownAddress(t);
        const n = e.to ? (0,
        g.ensureAddressString)(e.to) : null
          , s = e.value != null ? (0,
        g.ensureBigInt)(e.value) : BigInt(0)
          , i = e.data ? (0,
        g.ensureBuffer)(e.data) : Buffer.alloc(0)
          , a = e.nonce != null ? (0,
        g.ensureIntNumber)(e.nonce) : null
          , o = e.gasPrice != null ? (0,
        g.ensureBigInt)(e.gasPrice) : null
          , c = e.maxFeePerGas != null ? (0,
        g.ensureBigInt)(e.maxFeePerGas) : null
          , l = e.maxPriorityFeePerGas != null ? (0,
        g.ensureBigInt)(e.maxPriorityFeePerGas) : null
          , h = e.gas != null ? (0,
        g.ensureBigInt)(e.gas) : null
          , f = e.chainId ? (0,
        g.ensureIntNumber)(e.chainId) : this.getChainId();
        return {
            fromAddress: t,
            toAddress: n,
            weiValue: s,
            data: i,
            nonce: a,
            gasPriceInWei: o,
            maxFeePerGas: c,
            maxPriorityFeePerGas: l,
            gasLimit: h,
            chainId: f
        }
    }
    _isAuthorized() {
        return this._addresses.length > 0
    }
    _requireAuthorization() {
        if (!this._isAuthorized())
            throw w.standardErrors.provider.unauthorized({})
    }
    _throwUnsupportedMethodError() {
        throw w.standardErrors.provider.unsupportedMethod({})
    }
    async _signEthereumMessage(e, t, n, s) {
        this._ensureKnownAddress(t);
        try {
            const a = await this.initializeRelay().signEthereumMessage(e, t, n, s);
            if ((0,
            D.isErrorResponse)(a))
                throw new Error(a.errorMessage);
            return {
                jsonrpc: "2.0",
                id: 0,
                result: a.result
            }
        } catch (i) {
            throw typeof i.message == "string" && i.message.match(/(denied|rejected)/i) ? w.standardErrors.provider.userRejectedRequest("User denied message signature") : i
        }
    }
    async _ethereumAddressFromSignedMessage(e, t, n) {
        const i = await this.initializeRelay().ethereumAddressFromSignedMessage(e, t, n);
        if ((0,
        D.isErrorResponse)(i))
            throw new Error(i.errorMessage);
        return {
            jsonrpc: "2.0",
            id: 0,
            result: i.result
        }
    }
    _eth_accounts() {
        return [...this._addresses]
    }
    _eth_coinbase() {
        return this.selectedAddress || null
    }
    _net_version() {
        return this.getChainId().toString(10)
    }
    _eth_chainId() {
        return (0,
        g.hexStringFromIntNumber)(this.getChainId())
    }
    getChainId() {
        const e = this._storage.getItem(Ke);
        if (!e)
            return (0,
            g.ensureIntNumber)(1);
        const t = parseInt(e, 10);
        return (0,
        g.ensureIntNumber)(t)
    }
    async _eth_requestAccounts() {
        if (this._isAuthorized())
            return Promise.resolve({
                jsonrpc: "2.0",
                id: 0,
                result: this._addresses
            });
        let e;
        try {
            if (e = await this.initializeRelay().requestEthereumAccounts(),
            (0,
            D.isErrorResponse)(e))
                throw new Error(e.errorMessage)
        } catch (t) {
            throw typeof t.message == "string" && t.message.match(/(denied|rejected)/i) ? w.standardErrors.provider.userRejectedRequest("User denied account authorization") : t
        }
        if (!e.result)
            throw new Error("accounts received is empty");
        return this._setAddresses(e.result),
        {
            jsonrpc: "2.0",
            id: 0,
            result: this._addresses
        }
    }
    _eth_sign(e) {
        this._requireAuthorization();
        const t = (0,
        g.ensureAddressString)(e[0])
          , n = (0,
        g.ensureBuffer)(e[1]);
        return this._signEthereumMessage(n, t, !1)
    }
    _eth_ecRecover(e) {
        const t = (0,
        g.ensureBuffer)(e[0])
          , n = (0,
        g.ensureBuffer)(e[1]);
        return this._ethereumAddressFromSignedMessage(t, n, !1)
    }
    _personal_sign(e) {
        this._requireAuthorization();
        const t = (0,
        g.ensureBuffer)(e[0])
          , n = (0,
        g.ensureAddressString)(e[1]);
        return this._signEthereumMessage(t, n, !0)
    }
    _personal_ecRecover(e) {
        const t = (0,
        g.ensureBuffer)(e[0])
          , n = (0,
        g.ensureBuffer)(e[1]);
        return this._ethereumAddressFromSignedMessage(t, n, !0)
    }
    async _eth_signTransaction(e) {
        this._requireAuthorization();
        const t = this._prepareTransactionParams(e[0] || {});
        try {
            const s = await this.initializeRelay().signEthereumTransaction(t);
            if ((0,
            D.isErrorResponse)(s))
                throw new Error(s.errorMessage);
            return {
                jsonrpc: "2.0",
                id: 0,
                result: s.result
            }
        } catch (n) {
            throw typeof n.message == "string" && n.message.match(/(denied|rejected)/i) ? w.standardErrors.provider.userRejectedRequest("User denied transaction signature") : n
        }
    }
    async _eth_sendRawTransaction(e) {
        const t = (0,
        g.ensureBuffer)(e[0])
          , s = await this.initializeRelay().submitEthereumTransaction(t, this.getChainId());
        if ((0,
        D.isErrorResponse)(s))
            throw new Error(s.errorMessage);
        return {
            jsonrpc: "2.0",
            id: 0,
            result: s.result
        }
    }
    async _eth_sendTransaction(e) {
        this._requireAuthorization();
        const t = this._prepareTransactionParams(e[0] || {});
        try {
            const s = await this.initializeRelay().signAndSubmitEthereumTransaction(t);
            if ((0,
            D.isErrorResponse)(s))
                throw new Error(s.errorMessage);
            return {
                jsonrpc: "2.0",
                id: 0,
                result: s.result
            }
        } catch (n) {
            throw typeof n.message == "string" && n.message.match(/(denied|rejected)/i) ? w.standardErrors.provider.userRejectedRequest("User denied transaction signature") : n
        }
    }
    async _eth_signTypedData_v1(e) {
        this._requireAuthorization();
        const t = (0,
        g.ensureParsedJSONObject)(e[0])
          , n = (0,
        g.ensureAddressString)(e[1]);
        this._ensureKnownAddress(n);
        const s = He.default.hashForSignTypedDataLegacy({
            data: t
        })
          , i = JSON.stringify(t, null, 2);
        return this._signEthereumMessage(s, n, !1, i)
    }
    async _eth_signTypedData_v3(e) {
        this._requireAuthorization();
        const t = (0,
        g.ensureAddressString)(e[0])
          , n = (0,
        g.ensureParsedJSONObject)(e[1]);
        this._ensureKnownAddress(t);
        const s = He.default.hashForSignTypedData_v3({
            data: n
        })
          , i = JSON.stringify(n, null, 2);
        return this._signEthereumMessage(s, t, !1, i)
    }
    async _eth_signTypedData_v4(e) {
        this._requireAuthorization();
        const t = (0,
        g.ensureAddressString)(e[0])
          , n = (0,
        g.ensureParsedJSONObject)(e[1]);
        this._ensureKnownAddress(t);
        const s = He.default.hashForSignTypedData_v4({
            data: n
        })
          , i = JSON.stringify(n, null, 2);
        return this._signEthereumMessage(s, t, !1, i)
    }
    async _wallet_addEthereumChain(e) {
        var t, n, s, i;
        const a = e[0];
        if (((t = a.rpcUrls) === null || t === void 0 ? void 0 : t.length) === 0)
            return {
                jsonrpc: "2.0",
                id: 0,
                error: {
                    code: 2,
                    message: "please pass in at least 1 rpcUrl"
                }
            };
        if (!a.chainName || a.chainName.trim() === "")
            throw w.standardErrors.rpc.invalidParams("chainName is a required field");
        if (!a.nativeCurrency)
            throw w.standardErrors.rpc.invalidParams("nativeCurrency is a required field");
        const o = parseInt(a.chainId, 16);
        return await this.addEthereumChain(o, (n = a.rpcUrls) !== null && n !== void 0 ? n : [], (s = a.blockExplorerUrls) !== null && s !== void 0 ? s : [], a.chainName, (i = a.iconUrls) !== null && i !== void 0 ? i : [], a.nativeCurrency) ? {
            jsonrpc: "2.0",
            id: 0,
            result: null
        } : {
            jsonrpc: "2.0",
            id: 0,
            error: {
                code: 2,
                message: "unable to add ethereum chain"
            }
        }
    }
    async _wallet_switchEthereumChain(e) {
        const t = e[0];
        return await this.switchEthereumChain(parseInt(t.chainId, 16)),
        {
            jsonrpc: "2.0",
            id: 0,
            result: null
        }
    }
    async _wallet_watchAsset(e) {
        const t = Array.isArray(e) ? e[0] : e;
        if (!t.type)
            throw w.standardErrors.rpc.invalidParams("Type is required");
        if ((t == null ? void 0 : t.type) !== "ERC20")
            throw w.standardErrors.rpc.invalidParams(`Asset of type '${t.type}' is not supported`);
        if (!(t != null && t.options))
            throw w.standardErrors.rpc.invalidParams("Options are required");
        if (!(t != null && t.options.address))
            throw w.standardErrors.rpc.invalidParams("Address is required");
        const n = this.getChainId()
          , {address: s, symbol: i, image: a, decimals: o} = t.options;
        return {
            jsonrpc: "2.0",
            id: 0,
            result: await this.watchAsset(t.type, s, i, o, a, n)
        }
    }
    initializeRelay() {
        if (!this._relay) {
            const e = new Zn.WalletLinkRelay({
                linkAPIUrl: gt.WALLETLINK_URL,
                storage: this._storage
            });
            e.setAppInfo(this._appName, this._appLogoUrl),
            e.attachUI(),
            e.setAccountsCallback( (t, n) => this._setAddresses(t, n)),
            e.setChainCallback( (t, n) => {
                this.updateProviderInfo(n, parseInt(t, 10))
            }
            ),
            this._relay = e
        }
        return this._relay
    }
}
Se.WalletLinkSigner = Yn;
var k = {};
Object.defineProperty(k, "__esModule", {
    value: !0
});
k.checkErrorForInvalidRequestArgs = k.getCoinbaseInjectedProvider = k.getCoinbaseInjectedSigner = k.fetchRPCRequest = void 0;
const Jn = K
  , ge = O;
async function Qn(r, e) {
    if (!e.rpcUrl)
        throw ge.standardErrors.rpc.internal("No RPC URL set for chain");
    const t = Object.assign(Object.assign({}, r), {
        jsonrpc: "2.0",
        id: crypto.randomUUID()
    });
    return (await (await window.fetch(e.rpcUrl, {
        method: "POST",
        body: JSON.stringify(t),
        mode: "cors",
        headers: {
            "Content-Type": "application/json",
            "X-Cbw-Sdk-Version": Jn.LIB_VERSION
        }
    })).json()).result
}
k.fetchRPCRequest = Qn;
function Gt() {
    return globalThis.coinbaseWalletSigner
}
k.getCoinbaseInjectedSigner = Gt;
function Xn({metadata: r, preference: e}) {
    var t, n, s;
    const i = globalThis;
    if (e.options !== "smartWalletOnly") {
        if (Gt())
            return;
        const c = i.coinbaseWalletExtension;
        if (c) {
            const {appName: l, appLogoUrl: h, appChainIds: f} = r;
            return (t = c.setAppInfo) === null || t === void 0 || t.call(c, l, h, f),
            c
        }
    }
    const a = (n = i.ethereum) !== null && n !== void 0 ? n : (s = i.top) === null || s === void 0 ? void 0 : s.ethereum;
    if (a != null && a.isCoinbaseBrowser)
        return a
}
k.getCoinbaseInjectedProvider = Xn;
function es(r) {
    if (!r || typeof r != "object" || Array.isArray(r))
        return ge.standardErrors.rpc.invalidParams({
            message: "Expected a single, non-array, object argument.",
            data: r
        });
    const {method: e, params: t} = r;
    if (typeof e != "string" || e.length === 0)
        return ge.standardErrors.rpc.invalidParams({
            message: "'args.method' must be a non-empty string.",
            data: r
        });
    if (t !== void 0 && !Array.isArray(t) && (typeof t != "object" || t === null))
        return ge.standardErrors.rpc.invalidParams({
            message: "'args.params' must be an object or array if provided.",
            data: r
        })
}
k.checkErrorForInvalidRequestArgs = es;
Object.defineProperty(P, "__esModule", {
    value: !0
});
P.createSigner = P.fetchSignerType = P.storeSignerType = P.loadSignerType = void 0;
const ts = ve
  , Yt = Se
  , rs = O
  , ns = k
  , ss = j
  , Jt = "SignerType"
  , Qt = new ss.ScopedLocalStorage("CBWSDK","SignerConfigurator");
function is() {
    return Qt.getItem(Jt)
}
P.loadSignerType = is;
function as(r) {
    Qt.setItem(Jt, r)
}
P.storeSignerType = as;
async function os(r) {
    const {communicator: e, metadata: t} = r;
    ds(e, t).catch( () => {}
    );
    const n = {
        id: crypto.randomUUID(),
        event: "selectSignerType",
        data: r.preference
    }
      , {data: s} = await e.postRequestAndWaitForResponse(n);
    return s
}
P.fetchSignerType = os;
function cs(r) {
    const {signerType: e, metadata: t, communicator: n, updateListener: s} = r;
    switch (e) {
    case "scw":
        return new ts.SCWSigner({
            metadata: t,
            updateListener: s,
            communicator: n
        });
    case "walletlink":
        return new Yt.WalletLinkSigner({
            metadata: t,
            updateListener: s
        });
    case "extension":
        {
            const i = (0,
            ns.getCoinbaseInjectedSigner)();
            if (!i)
                throw rs.standardErrors.rpc.internal("injected signer not found");
            return i
        }
    }
}
P.createSigner = cs;
async function ds(r, e) {
    await r.onMessage( ({event: n}) => n === "WalletLinkSessionRequest");
    const t = new Yt.WalletLinkSigner({
        metadata: e
    });
    r.postMessage({
        event: "WalletLinkUpdate",
        data: {
            session: t.getSession()
        }
    }),
    await t.handshake(),
    r.postMessage({
        event: "WalletLinkUpdate",
        data: {
            connected: !0
        }
    })
}
var Ne = {}
  , J = {};
Object.defineProperty(J, "__esModule", {
    value: !0
});
J.closePopup = J.openPopup = void 0;
const ls = O
  , ft = 420
  , mt = 540;
function us(r) {
    const e = (window.innerWidth - ft) / 2 + window.screenX
      , t = (window.innerHeight - mt) / 2 + window.screenY
      , n = window.open(r, "Smart Wallet", `width=${ft}, height=${mt}, left=${e}, top=${t}`);
    if (n == null || n.focus(),
    !n)
        throw ls.standardErrors.rpc.internal("Pop up window failed to open");
    return n
}
J.openPopup = us;
function hs(r) {
    r && !r.closed && r.close()
}
J.closePopup = hs;
Object.defineProperty(Ne, "__esModule", {
    value: !0
});
Ne.Communicator = void 0;
const gs = K
  , bt = J
  , ps = T
  , yt = O;
class fs {
    constructor(e=ps.CB_KEYS_URL) {
        this.popup = null,
        this.listeners = new Map,
        this.postMessage = async t => {
            (await this.waitForPopupLoaded()).postMessage(t, this.url.origin)
        }
        ,
        this.postRequestAndWaitForResponse = async t => {
            const n = this.onMessage( ({requestId: s}) => s === t.id);
            return this.postMessage(t),
            await n
        }
        ,
        this.onMessage = async t => new Promise( (n, s) => {
            const i = a => {
                if (a.origin !== this.url.origin)
                    return;
                const o = a.data;
                t(o) && (n(o),
                window.removeEventListener("message", i),
                this.listeners.delete(i))
            }
            ;
            window.addEventListener("message", i),
            this.listeners.set(i, {
                reject: s
            })
        }
        ),
        this.disconnect = () => {
            (0,
            bt.closePopup)(this.popup),
            this.popup = null,
            this.listeners.forEach( ({reject: t}, n) => {
                t(yt.standardErrors.provider.userRejectedRequest("Request rejected")),
                window.removeEventListener("message", n)
            }
            ),
            this.listeners.clear()
        }
        ,
        this.waitForPopupLoaded = async () => this.popup && !this.popup.closed ? this.popup : (this.popup = (0,
        bt.openPopup)(this.url),
        this.onMessage( ({event: t}) => t === "PopupUnload").then(this.disconnect).catch( () => {}
        ),
        this.onMessage( ({event: t}) => t === "PopupLoaded").then(t => {
            this.postMessage({
                requestId: t.id,
                data: {
                    version: gs.LIB_VERSION
                }
            })
        }
        ).then( () => {
            if (!this.popup)
                throw yt.standardErrors.rpc.internal();
            return this.popup
        }
        )),
        this.url = new URL(e)
    }
}
Ne.Communicator = fs;
var Te = {};
Object.defineProperty(Te, "__esModule", {
    value: !0
});
Te.determineMethodCategory = void 0;
const wt = {
    handshake: ["eth_requestAccounts"],
    sign: ["eth_ecRecover", "personal_sign", "personal_ecRecover", "eth_signTransaction", "eth_sendTransaction", "eth_signTypedData_v1", "eth_signTypedData_v3", "eth_signTypedData_v4", "eth_signTypedData", "wallet_addEthereumChain", "wallet_switchEthereumChain", "wallet_watchAsset", "wallet_getCapabilities", "wallet_sendCalls", "wallet_showCallsStatus"],
    state: ["eth_chainId", "eth_accounts", "eth_coinbase", "net_version"],
    deprecated: ["eth_sign", "eth_signTypedData_v2"],
    unsupported: ["eth_subscribe", "eth_unsubscribe"],
    fetch: []
};
function ms(r) {
    for (const e in wt) {
        const t = e;
        if (wt[t].includes(r))
            return t
    }
}
Te.determineMethodCategory = ms;
var bs = M && M.__rest || function(r, e) {
    var t = {};
    for (var n in r)
        Object.prototype.hasOwnProperty.call(r, n) && e.indexOf(n) < 0 && (t[n] = r[n]);
    if (r != null && typeof Object.getOwnPropertySymbols == "function")
        for (var s = 0, n = Object.getOwnPropertySymbols(r); s < n.length; s++)
            e.indexOf(n[s]) < 0 && Object.prototype.propertyIsEnumerable.call(r, n[s]) && (t[n[s]] = r[n[s]]);
    return t
}
  , ys = M && M.__importDefault || function(r) {
    return r && r.__esModule ? r : {
        default: r
    }
}
;
Object.defineProperty(me, "__esModule", {
    value: !0
});
me.CoinbaseWalletProvider = void 0;
const ws = ys(ar)
  , z = O
  , vs = ye
  , qe = _
  , ue = u
  , he = P
  , vt = k
  , _s = Ne
  , Es = Te
  , Ss = j;
class Cs extends ws.default {
    constructor(e) {
        var t, n, {metadata: s} = e, i = e.preference, {keysUrl: a} = i, o = bs(i, ["keysUrl"]);
        super(),
        this.accounts = [],
        this.handlers = {
            handshake: async l => {
                try {
                    if (this.connected)
                        return this.emit("connect", {
                            chainId: (0,
                            ue.hexStringFromIntNumber)((0,
                            qe.IntNumber)(this.chain.id))
                        }),
                        this.accounts;
                    const h = await this.requestSignerSelection()
                      , f = this.initSigner(h)
                      , d = await f.handshake();
                    return this.signer = f,
                    (0,
                    he.storeSignerType)(h),
                    this.emit("connect", {
                        chainId: (0,
                        ue.hexStringFromIntNumber)((0,
                        qe.IntNumber)(this.chain.id))
                    }),
                    d
                } catch (h) {
                    throw this.handleUnauthorizedError(h),
                    h
                }
            }
            ,
            sign: async l => {
                if (!this.connected || !this.signer)
                    throw z.standardErrors.provider.unauthorized("Must call 'eth_requestAccounts' before other methods");
                try {
                    return await this.signer.request(l)
                } catch (h) {
                    throw this.handleUnauthorizedError(h),
                    h
                }
            }
            ,
            fetch: l => (0,
            vt.fetchRPCRequest)(l, this.chain),
            state: l => {
                const h = () => {
                    if (this.connected)
                        return this.accounts;
                    throw z.standardErrors.provider.unauthorized("Must call 'eth_requestAccounts' before other methods")
                }
                ;
                switch (l.method) {
                case "eth_chainId":
                case "net_version":
                    return this.chain.id;
                case "eth_accounts":
                    return h();
                case "eth_coinbase":
                    return h()[0];
                default:
                    return this.handlers.unsupported(l)
                }
            }
            ,
            deprecated: ({method: l}) => {
                throw z.standardErrors.rpc.methodNotSupported(`Method ${l} is deprecated.`)
            }
            ,
            unsupported: ({method: l}) => {
                throw z.standardErrors.rpc.methodNotSupported(`Method ${l} is not supported.`)
            }
        },
        this.isCoinbaseWallet = !0,
        this.updateListener = {
            onAccountsUpdate: ({accounts: l, source: h}) => {
                (0,
                ue.areAddressArraysEqual)(this.accounts, l) || (this.accounts = l,
                h !== "storage" && this.emit("accountsChanged", this.accounts))
            }
            ,
            onChainUpdate: ({chain: l, source: h}) => {
                l.id === this.chain.id && l.rpcUrl === this.chain.rpcUrl || (this.chain = l,
                h !== "storage" && this.emit("chainChanged", (0,
                ue.hexStringFromIntNumber)((0,
                qe.IntNumber)(l.id))))
            }
        },
        this.metadata = s,
        this.preference = o,
        this.communicator = new _s.Communicator(a),
        this.chain = {
            id: (n = (t = s.appChainIds) === null || t === void 0 ? void 0 : t[0]) !== null && n !== void 0 ? n : 1
        };
        const c = (0,
        he.loadSignerType)();
        this.signer = c ? this.initSigner(c) : null
    }
    get connected() {
        return this.accounts.length > 0
    }
    async request(e) {
        var t;
        try {
            const n = (0,
            vt.checkErrorForInvalidRequestArgs)(e);
            if (n)
                throw n;
            const s = (t = (0,
            Es.determineMethodCategory)(e.method)) !== null && t !== void 0 ? t : "fetch";
            return this.handlers[s](e)
        } catch (n) {
            return Promise.reject((0,
            vs.serializeError)(n, e.method))
        }
    }
    handleUnauthorizedError(e) {
        e.code === z.standardErrorCodes.provider.unauthorized && this.disconnect()
    }
    async enable() {
        return console.warn('.enable() has been deprecated. Please use .request({ method: "eth_requestAccounts" }) instead.'),
        await this.request({
            method: "eth_requestAccounts"
        })
    }
    async disconnect() {
        this.accounts = [],
        this.chain = {
            id: 1
        },
        Ss.ScopedLocalStorage.clearAll(),
        this.emit("disconnect", z.standardErrors.provider.disconnected("User initiated disconnection"))
    }
    requestSignerSelection() {
        return (0,
        he.fetchSignerType)({
            communicator: this.communicator,
            preference: this.preference,
            metadata: this.metadata
        })
    }
    initSigner(e) {
        return (0,
        he.createSigner)({
            signerType: e,
            metadata: this.metadata,
            communicator: this.communicator,
            updateListener: this.updateListener
        })
    }
}
me.CoinbaseWalletProvider = Cs;
Object.defineProperty(ee, "__esModule", {
    value: !0
});
ee.CoinbaseWalletSDK = void 0;
const ks = fe
  , Is = me
  , Ms = j
  , Ls = K
  , As = u
  , Rs = k;
class xs {
    constructor(e) {
        this.metadata = {
            appName: e.appName || "Dapp",
            appLogoUrl: e.appLogoUrl || (0,
            As.getFavicon)(),
            appChainIds: e.appChainIds || []
        },
        this.storeLatestVersion()
    }
    makeWeb3Provider(e={
        options: "all"
    }) {
        var t;
        const n = {
            metadata: this.metadata,
            preference: e
        };
        return (t = (0,
        Rs.getCoinbaseInjectedProvider)(n)) !== null && t !== void 0 ? t : new Is.CoinbaseWalletProvider(n)
    }
    getCoinbaseWalletLogo(e, t=240) {
        return (0,
        ks.walletLogo)(e, t)
    }
    storeLatestVersion() {
        new Ms.ScopedLocalStorage("CBWSDK").setItem("VERSION", Ls.LIB_VERSION)
    }
}
ee.CoinbaseWalletSDK = xs;
(function(r) {
    Object.defineProperty(r, "__esModule", {
        value: !0
    }),
    r.CoinbaseWalletSDK = void 0;
    const e = ee;
    r.default = e.CoinbaseWalletSDK;
    var t = ee;
    Object.defineProperty(r, "CoinbaseWalletSDK", {
        enumerable: !0,
        get: function() {
            return t.CoinbaseWalletSDK
        }
    })
}
)($e);
const Ps = rr($e)
  , Os = or({
    __proto__: null,
    default: Ps
}, [$e]);
export {Os as i};
